#!/usr/bin/env bash
# Genera el Gradle Wrapper (si falta) y compila el mod.
set -e
cd "$(dirname "$0")"

JV=$(java -version 2>&1 | head -1 | sed -E 's/.*"([0-9]+)(\.[0-9]+)*.*/\1/')
if [ "$JV" != "17" ]; then
  echo "!! Necesitas Java 17 (tienes: $JV). En Codespaces ejecuta:"
  echo "   sdk install java 17.0.12-tem && sdk use java 17.0.12-tem"
  exit 1
fi

if [ ! -f gradlew ]; then
  echo ">> Descargando Gradle 8.1.1 para generar el wrapper..."
  curl -fsSL https://services.gradle.org/distributions/gradle-8.1.1-bin.zip -o /tmp/gradle.zip
  unzip -q -o /tmp/gradle.zip -d /tmp
  /tmp/gradle-8.1.1/bin/gradle wrapper --gradle-version 8.1.1
fi

chmod +x gradlew
./gradlew build
echo ">> Listo. Tu .jar esta en build/libs/"
ls -1 build/libs/
