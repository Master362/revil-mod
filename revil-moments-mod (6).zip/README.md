# Revil Moments (Forge 1.20.1)

Mod **fan no oficial** para crear "Momentos ReviiL" al estilo del Dedsafio 4. Basado en los anuncios reales de la serie
(capturas de la Ruleta Roja). Todo se controla con comandos y se **personaliza sin programar** editando un JSON.

> Los Momentos ReviiL son **ACUMULATIVOS**: puedes activar varios a la vez (`/revil start` varias veces).

## Compilar en GitHub Codespaces
1. Sube `revil-moments-mod.zip` a un repo/Codespace.
2. `unzip -o revil-moments-mod.zip && rm revil-moments-mod.zip`
3. `sdk use java 17.0.12-tem` (si hace falta) y `bash setup.sh`
4. El mod queda en `build/libs/revilmoments-0.5.0.jar` (servidor y clientes).

## Empezar rapido
```
/revil list                            ver los momentos y sus tiempos
/revil bunker here 6                   bunker = cubo de radio 6 donde estas parado
/revil start bunker                    rayo mortal: todos al bunker (zona con particulas azules)
/revil start gas_abajo 2m              gas: 2 minutos para bajar a una capa negativa
/revil start gas_arriba_continuo 4m 45s   dura 4 min; el dano empieza a los 45 s
/revil start creepers_electricos
/revil stop                            cancelar todo
```
**Version definitiva:** el castigo es REAL desde el primer momento (`deadly = true`). Creativo y espectador nunca son afectados
(para probar a solas usa `/revil config deadly false` o `/tag <jugador> add revil_exempt`).

**Silencioso por defecto:** el mod NO muestra cuenta atras, ni titulo, ni mensaje de "momento ReviiL", ni avisa en el chat
cuando alguien falla (la serie lo anuncia por su cuenta). Si quieres alguno: `/revil config hud true`, `announce true`, `broadcast true`.

## Tiempos
- **`/revil start <momento> [duracion] [retraso]`**. Los tiempos aceptan `90`, `30s`, `2m`, `1m30s`, `1h` (`0` = sin limite).
  - **duracion**: tiempo TOTAL del momento, desde que lo lanzas hasta que termina (y se evalua el objetivo / se castiga).
  - **retraso**: tiempo de espera ANTES de que empiecen los efectos (ceguera, intercambio, creepers, Herobrine, dano continuo, tormenta,
    sin regeneracion, vida oculta...). La duracion incluye el retraso.
- En `moments.json` son `durationSeconds` y `delaySeconds` de cada momento (ajustalos hasta que quede igual que en la serie).
- Ejemplo: `gas_arriba_continuo` dura 240 s con 45 s de espera para subir; luego, dano cada segundo a quien no esta por encima de la capa 250.
- El contorno azul del bunker se ve desde el primer segundo (aunque los efectos aun no hayan empezado).

## Momentos incluidos (de las capturas)
| Id | Que hace |
|---|---|
| `gas_abajo` | Antes de que acabe el tiempo hay que estar en una capa negativa (Y ≤ -1) o recibes daño hasta morir |
| `gas_arriba` | Igual pero hay que estar por encima de la capa 250 |
| `gas_arriba_continuo` | Durante todo el evento hay que estar por encima de la 250 o recibes daño continuo |
| `posiciones_intercambiadas` | Teletransporta a todos intercambiando posiciones al azar (entre dimensiones también) |
| `sin_regeneracion` | Sin regeneración natural hasta que acabe el contador |
| `vida_oculta` | Los corazones desaparecen del HUD |
| `ceguera` | Ceguera unos segundos |
| `bunker` / `rayo_mortal` | Hay que estar dentro del bunker (contorno de **partículas azules**) o cae un rayo y mueres. Anuncia las coordenadas |
| `nether_desactivado` | Bunker + los portales del Nether no funcionan |
| `agujeros_negros` | Bunker + Nether desactivado + **3 agujeros negros** que bajan, crecen y **absorben bloques y jugadores** (ver abajo) |
| `supernova_alejarse` | Una supernova explota sobre el bunker: hay que **alejarse** (alcance 250 bloques) |
| `supernova_bunker` | La supernova explota en el epicentro (`/revil supernova set`); solo se salva quien esté **dentro del bunker** |
| `gran_supernova` | Onda expansiva enorme (2000 bloques) que puede alcanzar a casi todos |
| `escape_dimension` | La onda alcanza todo el Overworld: hay que **escapar a otra dimensión** antes de que explote |
| `creepers_electricos` | Creepers cargados con 1 de vida aparecen en tu posición en momentos aleatorios |
| `lluvia_creepers` | Lo mismo, con muchos más |
| `creepers_evolucionados` | Creepers cargados con 20 de vida |
| `cualquier_creeper` | Creeper normal o cargado, al azar |
| `ceguera_creepers`, `posiciones_creepers`, `vida_oculta_creepers` | Combos con creepers |
| `eclipse` | Hora fija a mediodia + **shader de eclipse** (oscuridad, disco negro con corona) |
| `eclipse_herobrine` | Eclipse + Herobrine (ver abajo). 20 s de espera antes de que aparezca |
| `luna_de_sangre` / `luna_sangre_creepers` | Noche fija; hay que estar en tu base (cerca de tu cama, radio 80) al terminar |
| `maldicion_luna` | El primero que mire a la Luna muere y la maldición se disipa (sin límite de tiempo) |
| `tormenta_electrica` | Clima de tormenta con rayos cerca de los jugadores |
| `bajo_agua` | Estar sumergido por completo al terminar (5 min) |
| `creepers_bajo_agua` | Permanecer bajo el agua todo el evento + creepers |
| `simulacro` | Solo el aviso: "esto es un simulacro" |

## Comandos (`/revil`, OP nivel 2)
| Comando | Que hace |
|---|---|
| `/revil list` / `status` | Lista / momentos activos |
| `/revil start <momento> [duracion] [retraso]` | Inicia un momento (acumulativo). Tiempos: `90`, `30s`, `2m`, `1m30s` |
| `/revil stop [momento]` | Cancela uno o todos (sin castigo) y quita el gas |
| `/revil reload` | Recarga los JSON |
| `/revil bunker set <x1> <y1> <z1> <x2> <y2> <z2>` | Define el bunker (caja) |
| `/revil bunker here <radio>` | Bunker = cubo alrededor de ti |
| `/revil bunker clear` / `show` | Quita / muestra el bunker |
| `/revil herobrine spawn` / `clear` | Prueba de Herobrine cerca de ti / quita todos |
| `/revil supernova set` / `clear` / `show` | Epicentro de las supernovas (si no se define: centro del bunker, o el spawn) |
| `/revil flashlight [jugador]` | Te da (o da a otro jugador) la **linterna** |
| `/revil config deadly <bool>` | Castigo real (por defecto) o modo pruebas |
| `/revil config announce <bool>` | Titulo + chat + sonido al iniciar (apagado) |
| `/revil config hud <bool>` | Cuenta atras y objetivo en pantalla (apagado) |
| `/revil config broadcast <bool>` | Mensaje en el chat cuando alguien falla (apagado) |
| `/revil config totem <bool>` | Un Totem en la mano evita el castigo (lo consume) |

Excluir a alguien: `/tag <jugador> add revil_exempt`.

## Herobrine
- **Aspecto:** tu skin (ojos blancos) con **ojos que brillan en la oscuridad**. Pasos silenciosos.
- **Acecho:** aparece a 28-46 bloques y camina despacio hacia el jugador mas cercano, mirandolo. Si queda muy lejos se acerca de golpe.
- **Furia:** si cualquier jugador lo **mira a los ojos** (formula del Enderman) se enfurece contra ese jugador y lo golpea con mucho dano
  (`herobrineDamage`, por defecto 14 = 7 corazones).
- **No se deja escapar:** subirte a un pilar, al techo o al agua ya no sirve. Si no puede llegar a ti (se atora, no hay camino o estas
  3-4 bloques mas arriba) **se teletransporta pegado a ti y te golpea**; si estas lejos, aparece cerca. Su alcance cubre ~4 bloques de desnivel.
- **Intocable:** no se le puede danar (solo creativo y comandos).
- **Linterna:** ver abajo. Mientras la luz le da, queda **paralizado** (no se mueve ni ataca) y a **1 segundo desaparece** con humo.
- Se elimina solo al terminar el momento. Prueba: `/revil herobrine spawn` y `/revil herobrine clear`.
- Lo confirmado de la serie: aparece, camina hacia los jugadores, quien lo ve termina mal y la linterna lo hace desaparecer.
  Los numeros exactos (dano, velocidad, alcance) son una aproximacion: ajustalos en `moments.json`.

## Linterna (item) y shader de luz
- Item `revilmoments:flashlight` ("Linterna"): `/give @p revilmoments:flashlight`, en el creativo (pestaña Herramientas) o con receta:
  `  vidrio  ` / `hierro redstone hierro` / `  hierro  ` (panel de vidrio arriba, redstone al centro, hierro en los lados y abajo).
- **Clic derecho** = encender / apagar (brilla y suena cuando esta encendida).
- **Shader de luz (solo el que la sostiene, en primera persona):** cono con penumbra suave, atenuacion por distancia usando el buffer de
  profundidad, mas reflejo en superficies claras, punto caliente central, ligero parpadeo y difusion volumetrica del haz en el aire.
- Para ahuyentar a Herobrine hay que tenerla **encendida** y apuntarle ~1 s (se cambia con `banishItems`; puedes agregar `minecraft:lantern`).

## Shaders por momento (efectos de pantalla)
Usan el sistema de post-procesado de vanilla (carpeta `assets/revilmoments/shaders`), asi que son editables. Si un shader falla, se
desactiva solo sin cerrar el juego. Si usas un shaderpack de Optifine/Iris pueden no verse: `/revilfx off|on|reset` (comando de cliente).

| Efecto | Cuando | Que hace |
|---|---|---|
| `eclipse` | `eclipse`, `eclipse_herobrine` | Mundo oscuro y frio con viñeta + disco negro con corona en el sol. **Tambien oscurece la mano y los objetos en mano** |
| `gas` | Gas toxico | Viñeta verdosa que pulsa, ondulacion y desaturacion. **Tambien tiñe la mano** |
| `blackhole` | `agujeros_negros` | Lente gravitacional, horizonte negro y disco de acrecion; el terreno cercano los tapa |
| `supernova` | momentos de supernova | Estrella que crece y pulsa (puntas + halo); al explotar: destello blanco, **anillo de onda expansiva** que deforma la imagen con aberracion cromatica y tinte calido |
| `herobrine_eyes` | Cuando hay un Herobrine cerca | Los **ojos brillan** (nucleo, halo y destello horizontal) y **iluminan las superficies cercanas**; se ocultan si el terreno los tapa |
| `flashlight` | Linterna encendida | Cono con penumbra, atenuacion por distancia, reflejo segun la superficie y difusion del haz |

**Mano y objetos:** la mano se dibuja *despues* del mundo, por eso antes se veia "encendida" aunque todo estuviera oscuro. Ahora el eclipse y
el gas se vuelven a aplicar en un segundo pase **solo a los pixeles de la mano** (los unicos con profundidad < 1 en ese momento).

## Agujeros negros (`agujeros_negros`)
- Aparecen en el cielo alrededor del bunker, **bajan y se acercan** durante el momento, y su **nivel sube de 0 a 10** con el tiempo.
- **Absorben bloques** de la superficie (cada vez mas por segundo; hasta 160 a la vez) que vuelan hacia ellos y desaparecen. El bunker (+4 bloques) no se toca.
- **Jalan a los jugadores fuera del bunker** (mas fuerte con el nivel; pueden subirlos por los aires) y **matan a quien los toca**.
- Al llegar al **nivel 10 (fin del tiempo)** absorben (matan) a **todos los que no esten en el bunker** (`failAction: absorb`).
- Ajustes en `moments.json`: `blackHoles`, `blackHoleRadius`, `blackHoleGrowth`, `blackHoleAbsorb`, `delaySeconds`.

## Supernovas
- Una **estrella** crece en el cielo sobre el epicentro durante el momento (shader + latidos y zumbido) y **explota al terminar el tiempo**.
- La **onda expansiva** avanza `supernovaSpeed` bloques/s hasta `supernovaMaxRadius`: mata a quien alcanza, salvo dentro del bunker si
  `supernovaSafe` es `bunker`. Quien esta mas lejos del alcance, o en otra dimension, sobrevive.
- **Epicentro:** `/revil supernova set` (donde estes parado). Sin definir: el centro del bunker, o el spawn.
  - *Alejarse* (la supernova esta sobre el bunker): `supernova_alejarse`. *Llegar a otro bunker*: pon el epicentro en el bunker A, define el bunker B con `/revil bunker ...` y usa `supernova_bunker`.
- **Crater opcional:** `supernovaCrater` (radio en bloques, 0 = apagado por defecto) excava una esfera en el epicentro respetando el bunker.
- `/revil stop` cancela la supernova (no explota).

## Crear / editar momentos
`config/revilmoments/moments.json` (se genera al abrir el servidor; si existía el de la versión anterior se respalda como
`moments_anterior_backup.json`). Copia un bloque, cambia el `"id"`, y `/revil reload`. Ejemplo:
```json
{
  "id": "mi_momento",
  "name": "&fGas y creepers",
  "description": "¡ReviiL soltó gas! Bajen a una capa negativa. Diríjanse a %bunker%.",
  "durationSeconds": 150,
  "objective": "below",
  "objectiveY": -1,
  "failAction": "gas",
  "creeperMode": "electric",
  "creeperHealth": 1,
  "creeperEvents": 3,
  "then": "bajo_agua"
}
```
Campos principales:
- **Textos**: `title`, `name` (subtítulo), `description` (chat), `objectiveText` (HUD), `successMessage`; códigos `&`, placeholders `%bunker%` y `%y%`.
- **Tiempo**: `durationSeconds` (total; 0 = sin límite), `delaySeconds` (espera antes de los efectos), `showTimer`, `sounds`.
- **Objetivo**: `objective` = `none` | `bunker` | `above` | `below` | `underwater` | `base`; `objectiveY`; `baseRadius`;
  `objectiveMode` = `end` (se evalúa al acabar) | `during` (daño cada segundo mientras no se cumpla).
- **Castigo**: `failAction` = `none` | `kill` | `lightning` | `absorb` (agujero negro) | `gas` (daño por segundo que **sube un 10 % cada segundo, hasta x3**, hasta que cumplas o mueras; `gasDamage`) | `damage` | `command` (`failCommand`, `%player%`).
- **Efectos**: `blindnessSeconds`, `noRegen`, `hideHealth`, `swapPositions`, `creeperMode` (`none`|`electric`|`any`), `creeperHealth`,
  `creeperEvents`, `forceTime`, `thunderstorm`, `disableNether`, `herobrine`, `herobrineCount`, `herobrineDamage`, `banishItems`, `blackHoles`, `blackHoleRadius`, `blackHoleGrowth`, `blackHoleAbsorb`, `eclipseShader`, `supernova`, `supernovaHeight`, `supernovaMaxRadius`, `supernovaSpeed`, `supernovaSafe`, `supernovaCrater`, `moonCurse`, `bunkerParticles`, `dimensions`.
- **Al terminar**: `endCommand`, `then` (siguiente momento) y `thenDelaySeconds`.

Ajustes globales: `config/revilmoments/config.json` (`deadly`, `totemSaves`, `announce`, `showHud`, `broadcastFails`, `dimensions`; por defecto Overworld, Nether y End).
Si vienes de una version anterior, `config.json` y `moments.json` se actualizan solos (el viejo se respalda).

## Que NO incluye (necesita contenido propio muy grande o es de otra índole)
Limbo, Gleba, Cubo Phora, Medusas Óseas, Zombies que construyen, tornados, nutrias, zombificación, almas, visual de los
agujeros negros y la animación de la Ruleta. Se pueden ir agregando por separado.
Tampoco hay meteoritos, supernova, gulag ni cielo rojo (retirados a pedido).

## Notas
- "Base" = tu punto de reaparición (cama/ancla); si no tienes, el spawn del mundo.
- Los rayos de la tormenta son reales (pueden prender fuego); el del castigo `lightning` es solo visual y el daño lo aplica el mod.
- El Creeper Eléctrico es un creeper cargado con la vida indicada (aparece vía `/summon`).
- Sonidos y efectos son de vanilla/propios; no se usa ningún audio ni asset de la serie.
