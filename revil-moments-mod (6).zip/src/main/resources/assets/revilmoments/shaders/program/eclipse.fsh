#version 150

// Eclipse solar: mundo oscuro y frio, vineta, disco negro con corona donde esta el sol.
// HandOnly = 1 -> segundo pase: oscurece SOLO la mano y los objetos en mano (para que no se vean "encendidos"
// en un mundo oscuro). El primer pase (HandOnly = 0) se hace antes de dibujar la mano.
uniform sampler2D DiffuseSampler;
uniform sampler2D DiffuseDepthSampler;

uniform float Strength;
uniform float Aspect;
uniform float CenterX;
uniform float CenterY;
uniform float Radius;
uniform float Visible;
uniform float Phase;
uniform float HandOnly;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec3 src = texture(DiffuseSampler, texCoord).rgb;
    float depth = texture(DiffuseDepthSampler, texCoord).r;
    float sky = step(0.9999, depth);
    float hand = 1.0 - sky;
    float mask = mix(1.0, hand, HandOnly);

    // oscurecer y enfriar
    float lum = dot(src, vec3(0.299, 0.587, 0.114));
    vec3 dim = mix(src, vec3(lum) * vec3(0.72, 0.82, 1.0), 0.55 * Strength);
    dim *= 1.0 - 0.78 * Strength;

    // vineta
    vec2 q = texCoord - 0.5;
    q.x *= Aspect;
    float vig = smoothstep(0.30, 0.95, length(q));
    dim *= 1.0 - 0.5 * Strength * vig;

    // disco negro (luna) y corona: solo en el pase del mundo
    vec2 d = texCoord - vec2(CenterX, CenterY);
    d.x *= Aspect;
    float r = length(d) + 0.00001;
    float R = max(Radius, 0.001);
    float disc = 1.0 - smoothstep(R * 0.96, R, r);
    float t = max(r - R, 0.0) / (R * 0.55);
    float glow = exp(-t * 1.6);
    float rays = 0.55 + 0.45 * pow(abs(cos(atan(d.y, d.x) * 5.0 + Phase * 0.3)), 6.0);
    vec3 corona = vec3(1.0, 0.93, 0.82) * glow * rays * (1.0 - disc);

    float k = sky * Visible * Strength * (1.0 - HandOnly);
    dim = mix(dim, vec3(0.0), disc * k);
    dim += corona * 1.3 * k;

    fragColor = vec4(mix(src, dim, mask), 1.0);
}
