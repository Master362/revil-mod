#version 150

// Agujero negro: lente gravitacional, horizonte de sucesos, disco de acrecion con efecto Doppler y halo.
// Solo afecta a los pixeles que estan MAS LEJOS que el agujero (el terreno cercano lo tapa).
uniform sampler2D DiffuseSampler;
uniform sampler2D DiffuseDepthSampler;

uniform float CenterX;
uniform float CenterY;
uniform float Radius;
uniform float Strength;
uniform float Aspect;
uniform float Phase;
uniform float HoleDist;
uniform float Near;
uniform float Far;

in vec2 texCoord;
out vec4 fragColor;

float linearDepth(float d) {
    float z = d * 2.0 - 1.0;
    return (2.0 * Near * Far) / (Far + Near - z * (Far - Near));
}

void main() {
    vec2 uv = texCoord;
    float sceneDist = linearDepth(texture(DiffuseDepthSampler, uv).r);
    float behind = step(HoleDist, sceneDist);

    vec2 c = vec2(CenterX, CenterY);
    vec2 d = uv - c;
    d.x *= Aspect;
    float r = length(d) + 0.00001;
    float R = max(Radius, 0.001);

    // lente gravitacional: la imagen se curva alrededor del agujero
    float bend = Strength * (R * R) / (r * r + R * R * 0.35);
    vec2 dir = d / r;
    vec2 off = dir * bend * 0.55;
    off.x /= Aspect;
    vec3 col = texture(DiffuseSampler, uv - off * behind).rgb;

    // horizonte de sucesos
    float horizon = (1.0 - smoothstep(R * 0.55, R * 0.65, r)) * behind;
    col = mix(col, vec3(0.0), clamp(horizon * Strength * 1.5, 0.0, 1.0));

    // disco de acrecion
    float ringR = R * 0.9;
    float t = (r - ringR) / (R * 0.2);
    float ring = exp(-t * t);
    float ang = atan(d.y, d.x);
    float swirl = 0.65 + 0.35 * sin(ang * 3.0 - Phase * 6.0 + r * 14.0 / R);
    float doppler = 0.6 + 0.4 * cos(ang - 0.6);
    vec3 hot = mix(vec3(1.0, 0.40, 0.08), vec3(1.0, 0.92, 0.65), ring);
    col += hot * ring * swirl * doppler * Strength * 1.8 * behind;

    // halo tenue
    col += vec3(0.9, 0.5, 0.2) * exp(-r / (R * 2.2)) * 0.12 * Strength * behind;

    fragColor = vec4(col, 1.0);
}
