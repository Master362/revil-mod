#version 150

// Linterna: cono con penumbra suave, atenuacion por distancia (usa el buffer de profundidad),
// reflexion segun el color de la superficie, punto caliente central y ligera difusion volumetrica en el aire.
uniform sampler2D DiffuseSampler;
uniform sampler2D DiffuseDepthSampler;

uniform float Intensity;
uniform float Aspect;
uniform float CenterX;
uniform float CenterY;
uniform float Inner;
uniform float Outer;
uniform float Range;
uniform float Near;
uniform float Far;
uniform float Phase;

in vec2 texCoord;
out vec4 fragColor;

float linearDepth(float d) {
    float z = d * 2.0 - 1.0;
    return (2.0 * Near * Far) / (Far + Near - z * (Far - Near));
}

void main() {
    vec3 base = texture(DiffuseSampler, texCoord).rgb;
    float depth = texture(DiffuseDepthSampler, texCoord).r;
    float dist = linearDepth(depth);

    vec2 p = texCoord - vec2(CenterX, CenterY);
    p.x *= Aspect;
    float r = length(p);

    float cone = 1.0 - smoothstep(Inner, Outer, r);
    cone *= cone;

    float atten = 1.0 / (1.0 + (dist / Range) * (dist / Range) * 1.6);
    float hit = step(depth, 0.99999);   // solo superficies, no el cielo

    vec3 lightCol = vec3(1.0, 0.92, 0.76);
    float lit = cone * atten * hit * Intensity;

    // las superficies claras reflejan mas; las oscuras reciben una luz minima
    vec3 added = lightCol * lit * (0.22 + 1.4 * base);

    // difusion volumetrica (se ve el haz en el aire)
    float scatter = cone * (1.0 - exp(-min(dist, Range * 2.0) / (Range * 0.9))) * 0.05 * Intensity;

    // punto caliente
    float hot = exp(-(r * r) / 0.0025) * hit * atten * 0.15;

    vec3 col = base + added + lightCol * (scatter * (1.0 - hit * 0.5) + hot);
    fragColor = vec4(col, 1.0);
}
