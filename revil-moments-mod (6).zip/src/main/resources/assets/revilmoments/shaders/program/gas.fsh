#version 150

// Gas toxico: vineta verdosa que pulsa + ligera ondulacion + desaturacion enfermiza.
// HandOnly = 1 -> segundo pase (despues de dibujar la mano): solo se aplica a los pixeles de la mano / objetos en mano,
// que son los unicos con profundidad < 1 en ese momento (la mano se dibuja tras limpiar el buffer de profundidad).
uniform sampler2D DiffuseSampler;
uniform sampler2D DiffuseDepthSampler;

uniform float Strength;
uniform float Aspect;
uniform float Phase;
uniform float HandOnly;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    float depth = texture(DiffuseDepthSampler, texCoord).r;
    float hand = step(depth, 0.9999);
    float mask = mix(1.0, hand, HandOnly);

    vec2 uv = texCoord;
    float wob = 0.004 * Strength * (1.0 - HandOnly);
    uv += wob * vec2(sin(uv.y * 14.0 + Phase * 3.0), cos(uv.x * 12.0 + Phase * 2.4));
    vec3 src = texture(DiffuseSampler, uv).rgb;

    float lum = dot(src, vec3(0.299, 0.587, 0.114));
    vec3 col = mix(src, vec3(lum) * vec3(0.8, 1.0, 0.55), 0.45 * Strength);

    vec2 q = texCoord - 0.5;
    q.x *= Aspect;
    float vig = smoothstep(0.25, 0.9, length(q));
    float pulse = 0.75 + 0.25 * sin(Phase * 4.0);
    col = mix(col, vec3(0.05, 0.22, 0.04), vig * 0.65 * Strength * pulse);

    fragColor = vec4(mix(texture(DiffuseSampler, texCoord).rgb, col, mask), 1.0);
}
