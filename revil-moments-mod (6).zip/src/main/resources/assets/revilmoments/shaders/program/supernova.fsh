#version 150

// Supernova: estrella que crece y pulsa (con puntas y halo), la tapa el terreno cercano (profundidad);
// al explotar: destello blanco, anillo de onda expansiva que deforma la imagen con aberracion cromatica,
// y un tinte calido que se desvanece.
uniform sampler2D DiffuseSampler;
uniform sampler2D DiffuseDepthSampler;

uniform float CenterX;
uniform float CenterY;
uniform float StarR;
uniform float StarDist;
uniform float EpiX;
uniform float EpiY;
uniform float WaveR;
uniform float WaveW;
uniform float Charge;
uniform float Flash;
uniform float Tint;
uniform float Aspect;
uniform float Phase;
uniform float Near;
uniform float Far;
uniform float Exploded;

in vec2 texCoord;
out vec4 fragColor;

float linearDepth(float d) {
    float z = d * 2.0 - 1.0;
    return (2.0 * Near * Far) / (Far + Near - z * (Far - Near));
}

void main() {
    vec2 uv = texCoord;
    float sceneDist = linearDepth(texture(DiffuseDepthSampler, uv).r);
    float starVisible = step(StarDist, sceneDist);

    // onda expansiva: anillo que deforma la imagen
    vec2 e = uv - vec2(EpiX, EpiY);
    e.x *= Aspect;
    float er = length(e) + 0.00001;
    float ring = 0.0;
    if (WaveR > 0.0) {
        float t = (er - WaveR) / max(WaveW, 0.001);
        ring = exp(-t * t);
    }
    vec2 off = (e / er) * ring * 0.03;
    off.x /= Aspect;
    vec2 suv = uv - off;
    vec3 col;
    col.r = texture(DiffuseSampler, suv + off * 0.35).r;   // aberracion cromatica
    col.g = texture(DiffuseSampler, suv).g;
    col.b = texture(DiffuseSampler, suv - off * 0.35).b;
    col += vec3(1.0, 0.8, 0.5) * ring * 0.35;

    // estrella
    vec2 d = uv - vec2(CenterX, CenterY);
    d.x *= Aspect;
    float r = length(d) + 0.00001;
    float R = max(StarR, 0.002);
    float tc = r / (R * 0.5);
    float core = exp(-tc * tc);
    float halo = exp(-r / (R * 2.5));
    float ang = atan(d.y, d.x);
    float spikes = pow(abs(cos(ang * 3.0 + Phase * 0.3)), 30.0) * exp(-r / (R * 6.0)) * 0.9;
    vec3 hot = mix(vec3(0.7, 0.85, 1.0), vec3(1.0, 0.72, 0.35), Charge * 0.8 + Exploded * 0.2);
    vec3 star = vec3(1.0) * core * 2.0 + hot * (halo * 0.55 + spikes);
    col += star * starVisible * (0.35 + 0.65 * Charge) * (1.0 + Exploded * 1.5);

    // destello y tinte
    col = mix(col, vec3(1.0, 0.97, 0.9), clamp(Flash, 0.0, 1.0));
    col *= mix(vec3(1.0), vec3(1.0, 0.72, 0.5), clamp(Tint, 0.0, 1.0));

    fragColor = vec4(col, 1.0);
}
