#version 150

// Ojos de Herobrine: nucleo brillante + halo + destello horizontal + LUZ SOBRE LAS SUPERFICIES cercanas
// (usa la profundidad: ilumina lo que esta a una distancia parecida a la de los ojos). Se oculta si el terreno tapa los ojos.
uniform sampler2D DiffuseSampler;
uniform sampler2D DiffuseDepthSampler;

uniform float E1X;
uniform float E1Y;
uniform float E2X;
uniform float E2Y;
uniform float EyeDist;
uniform float Size;
uniform float Intensity;
uniform float Aspect;
uniform float Phase;
uniform float Near;
uniform float Far;
uniform float Range;

in vec2 texCoord;
out vec4 fragColor;

float linearDepth(float d) {
    float z = d * 2.0 - 1.0;
    return (2.0 * Near * Far) / (Far + Near - z * (Far - Near));
}

vec3 eyeLight(vec2 e, float sceneDist, float hit, float flick) {
    float de = linearDepth(texture(DiffuseDepthSampler, e).r);
    float vis = step(EyeDist - 0.6, de);          // 0 si el terreno tapa el ojo

    vec2 d = texCoord - e;
    d.x *= Aspect;
    float r = length(d) + 0.00001;
    float s = max(Size, 0.003);

    float core = exp(-(r * r) / (s * s * 0.5));
    float halo = exp(-(r * r) / (s * s * 6.0)) * 0.8;
    float flare = exp(-abs(d.x) / (s * 5.0)) * exp(-abs(d.y) / (s * 0.35)) * 0.35;

    float dz = abs(sceneDist - EyeDist);
    float surf = exp(-(r * r) / (s * s * 90.0)) * exp(-(dz * dz) / (Range * Range)) * hit * 0.55;

    vec3 tint = vec3(0.82, 0.90, 1.0);
    return tint * (core * 1.4 + halo + flare + surf) * vis * Intensity * flick;
}

void main() {
    vec3 base = texture(DiffuseSampler, texCoord).rgb;
    float depth = texture(DiffuseDepthSampler, texCoord).r;
    float sceneDist = linearDepth(depth);
    float hit = step(depth, 0.99999);
    float flick = 0.96 + 0.04 * sin(Phase * 31.0) * sin(Phase * 7.0);

    vec3 col = base + eyeLight(vec2(E1X, E1Y), sceneDist, hit, flick) + eyeLight(vec2(E2X, E2Y), sceneDist, hit, flick);
    fragColor = vec4(col, 1.0);
}
