package com.example.revil;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.logging.LogUtils;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

/** Ajustes globales (config.json) y momentos (moments.json) en config/revilmoments/. */
public class RevilConfig {
    private static final Logger LOG = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final int VERSION = 3;            // config.json
    private static final int MOMENTS_VERSION = 5;    // moments.json

    /** true = el castigo es REAL (version definitiva). false = modo pruebas con avisos [PRUEBA]. */
    public static boolean deadly = true;
    /** true = un Totem de la Inmortalidad en la mano evita el castigo (lo consume). */
    public static boolean totemSaves = false;
    /** Titulo / chat / sonido de aviso al iniciar un momento. Apagado: la serie los anuncia por su cuenta. */
    public static boolean announce = false;
    /** Cuenta atras y objetivo en pantalla. Apagado por defecto. */
    public static boolean showHud = false;
    /** Mensaje en el chat cuando alguien falla o muere por un momento. */
    public static boolean broadcastFails = false;
    public static List<String> dimensions = defaultDims();

    public static final Map<String, MomentDef> MOMENTS = new LinkedHashMap<>();

    public static class Settings {
        public int version = 0;
        public boolean deadly = true;
        public boolean totemSaves = false;
        public boolean announce = false;
        public boolean showHud = false;
        public boolean broadcastFails = false;
        public List<String> dimensions = defaultDims();
    }

    public static class MomentFile {
        public int version = 0;
        public List<MomentDef> moments = new ArrayList<>();
    }

    private static List<String> defaultDims() {
        return new ArrayList<>(List.of("minecraft:overworld", "minecraft:the_nether", "minecraft:the_end"));
    }

    private static Path dir() {
        return FMLPaths.CONFIGDIR.get().resolve("revilmoments");
    }

    public static void load() {
        try {
            Files.createDirectories(dir());

            Path sp = dir().resolve("config.json");
            if (Files.exists(sp)) {
                Settings s = GSON.fromJson(Files.readString(sp), Settings.class);
                if (s != null && s.version >= VERSION) {
                    deadly = s.deadly;
                    totemSaves = s.totemSaves;
                    announce = s.announce;
                    showHud = s.showHud;
                    broadcastFails = s.broadcastFails;
                    if (s.dimensions != null && !s.dimensions.isEmpty()) dimensions = s.dimensions;
                } else {
                    // config de una version anterior: pasa a los valores de la version definitiva
                    deadly = true;
                    totemSaves = s != null && s.totemSaves;
                    announce = false;
                    showHud = false;
                    broadcastFails = false;
                    dimensions = defaultDims();
                    saveSettings();
                }
            } else {
                saveSettings();
            }

            Path mp = dir().resolve("moments.json");
            List<MomentDef> list = null;
            if (Files.exists(mp)) {
                MomentFile f = GSON.fromJson(Files.readString(mp), MomentFile.class);
                if (f != null && f.version >= MOMENTS_VERSION && f.moments != null) {
                    list = f.moments;
                } else {
                    Files.move(mp, dir().resolve("moments_anterior_backup.json"), StandardCopyOption.REPLACE_EXISTING);
                    LOG.info("Revil Moments: moments.json de una version anterior respaldado; se genera uno nuevo.");
                }
            }
            if (list == null) {
                list = Defaults.moments();
                MomentFile f = new MomentFile();
                f.version = MOMENTS_VERSION;
                f.moments = list;
                Files.writeString(mp, GSON.toJson(f));
            }
            fill(list);
        } catch (Exception e) {
            LOG.error("Revil Moments: no se pudo leer la configuracion, se usan los valores por defecto", e);
            if (MOMENTS.isEmpty()) fill(Defaults.moments());
        }
    }

    private static String nz(String s, String def) {
        return s == null ? def : s;
    }

    private static void fill(List<MomentDef> list) {
        MOMENTS.clear();
        for (MomentDef d : list) {
            if (d == null || d.id == null || d.id.isBlank()) continue;
            d.objective = nz(d.objective, "none");
            d.objectiveMode = nz(d.objectiveMode, "end");
            d.failAction = nz(d.failAction, "kill");
            d.creeperMode = nz(d.creeperMode, "none");
            d.supernovaSafe = nz(d.supernovaSafe, "bunker");
            d.title = nz(d.title, "");
            d.name = nz(d.name, "");
            d.description = nz(d.description, "");
            d.objectiveText = nz(d.objectiveText, "");
            d.successMessage = nz(d.successMessage, "");
            d.endCommand = nz(d.endCommand, "");
            d.failCommand = nz(d.failCommand, "");
            d.then = nz(d.then, "");
            if (d.messages == null) d.messages = new ArrayList<>();
            if (d.dimensions == null) d.dimensions = new ArrayList<>();
            if (d.banishItems == null) d.banishItems = new ArrayList<>();
            MOMENTS.put(d.id.toLowerCase(), d);
        }
    }

    public static void saveSettings() {
        try {
            Files.createDirectories(dir());
            Settings s = new Settings();
            s.version = VERSION;
            s.deadly = deadly;
            s.totemSaves = totemSaves;
            s.announce = announce;
            s.showHud = showHud;
            s.broadcastFails = broadcastFails;
            s.dimensions = dimensions;
            Files.writeString(dir().resolve("config.json"), GSON.toJson(s));
        } catch (Exception e) {
            LOG.error("Revil Moments: no se pudo guardar config.json", e);
        }
    }
}
