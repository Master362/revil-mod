package com.example.revil;

import com.example.revil.client.ClientRevil;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/**
 * Lo que ve cada jugador: lineas de HUD (opcional), si oculta su vida y los datos de los efectos de shader
 * (eclipse, gas toxico, agujeros negros).
 */
public class StatePacket {
    public static class Entry {
        public final String text;
        public final int remaining, total;
        public final boolean timer;

        public Entry(String text, int remaining, int total, boolean timer) {
            this.text = text;
            this.remaining = remaining;
            this.total = total;
            this.timer = timer;
        }
    }

    public final boolean hideHealth;
    public final List<Entry> entries;
    public final float eclipse, gas;
    /** x, y, z, radio (en bloques) de cada agujero negro. */
    public final List<double[]> holes;
    /** null o {x, y, z, altura, carga(0-1), explotada(0/1), ticksDesdeExplosion, velocidad, radioMax}. */
    public final double[] nova;

    public StatePacket(boolean hideHealth, List<Entry> entries, float eclipse, float gas, List<double[]> holes, double[] nova) {
        this.hideHealth = hideHealth;
        this.entries = entries;
        this.eclipse = eclipse;
        this.gas = gas;
        this.holes = holes;
        this.nova = nova;
    }

    public static void encode(StatePacket p, FriendlyByteBuf b) {
        b.writeBoolean(p.hideHealth);
        b.writeVarInt(p.entries.size());
        for (Entry e : p.entries) {
            b.writeUtf(e.text);
            b.writeVarInt(e.remaining);
            b.writeVarInt(e.total);
            b.writeBoolean(e.timer);
        }
        b.writeFloat(p.eclipse);
        b.writeFloat(p.gas);
        b.writeVarInt(p.holes.size());
        for (double[] h : p.holes) {
            b.writeDouble(h[0]);
            b.writeDouble(h[1]);
            b.writeDouble(h[2]);
            b.writeFloat((float) h[3]);
        }
        b.writeBoolean(p.nova != null);
        if (p.nova != null) {
            for (int i = 0; i < 9; i++) b.writeDouble(p.nova[i]);
        }
    }

    public static StatePacket decode(FriendlyByteBuf b) {
        boolean hide = b.readBoolean();
        int n = b.readVarInt();
        List<Entry> list = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String text = b.readUtf();
            int remaining = b.readVarInt();
            int total = b.readVarInt();
            boolean timer = b.readBoolean();
            list.add(new Entry(text, remaining, total, timer));
        }
        float eclipse = b.readFloat();
        float gas = b.readFloat();
        int hn = b.readVarInt();
        List<double[]> holes = new ArrayList<>();
        for (int i = 0; i < hn; i++) {
            double x = b.readDouble();
            double y = b.readDouble();
            double z = b.readDouble();
            double r = b.readFloat();
            holes.add(new double[]{x, y, z, r});
        }
        double[] nova = null;
        if (b.readBoolean()) {
            nova = new double[9];
            for (int i = 0; i < 9; i++) nova[i] = b.readDouble();
        }
        return new StatePacket(hide, list, eclipse, gas, holes, nova);
    }

    public static void handle(StatePacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> ClientRevil.apply(p));
        ctx.get().setPacketHandled(true);
    }
}
