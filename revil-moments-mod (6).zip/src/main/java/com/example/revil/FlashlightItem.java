package com.example.revil;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Linterna: clic derecho para encender/apagar. Encendida emite un haz de luz (shader en el cliente) que ahuyenta a Herobrine. */
public class FlashlightItem extends Item {

    public FlashlightItem(Properties props) {
        super(props);
    }

    public static boolean isOn(ItemStack s) {
        return s.getItem() instanceof FlashlightItem && s.hasTag() && s.getTag().getBoolean("On");
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean on = !isOn(stack);
        stack.getOrCreateTag().putBoolean("On", on);
        if (level instanceof ServerLevel sl) {
            RevilSounds.at(sl, player.getX(), player.getY(), player.getZ(), "ui.button.click",
                SoundSource.PLAYERS, 0.7f, on ? 1.4f : 0.9f);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return isOn(stack);   // brillo cuando esta encendida
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal(isOn(stack) ? "\u00a7aEncendida" : "\u00a77Apagada"));
        tooltip.add(Component.literal("\u00a78Clic derecho: encender / apagar"));
        tooltip.add(Component.literal("\u00a78Ap\u00fantala a Herobrine para ahuyentarlo"));
    }
}
