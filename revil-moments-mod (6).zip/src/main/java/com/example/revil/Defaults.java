package com.example.revil;

import java.util.ArrayList;
import java.util.List;

/** Momentos que se generan la primera vez en moments.json (basados en los eventos de la serie). */
public class Defaults {
    private static final String ACUM = " (Los Momentos ReviiL son ACUMULATIVOS.)";

    private static MomentDef m(String id, String name, String desc, int seconds) {
        MomentDef d = new MomentDef(id);
        d.name = "&f" + name;
        d.description = desc;
        d.durationSeconds = seconds;
        return d;
    }

    public static List<MomentDef> moments() {
        List<MomentDef> l = new ArrayList<>();

        // ---------------- gas toxico ----------------
        MomentDef d = m("gas_abajo", "Gas tóxico invisible",
            "¡ReviiL ha liberado un gas tóxico invisible! Antes de que termine el temporizador, TODOS deben DESCENDER a una capa negativa (de Y=-1 hacia abajo) o recibirán daño hasta morir.", 180);
        d.objective = "below"; d.objectiveY = -1; d.failAction = "gas";
        d.objectiveText = "&fDesciende a una capa negativa (Y ≤ -1)";
        l.add(d);

        d = m("gas_arriba", "Gas tóxico invisible",
            "¡ReviiL ha liberado un gas tóxico invisible en todas las dimensiones! Antes de que termine el temporizador TODOS deben estar POR ENCIMA de la capa 250 o recibirán daño hasta morir.", 180);
        d.objective = "above"; d.objectiveY = 250; d.failAction = "gas";
        d.objectiveText = "&fSube por encima de la capa %y%";
        l.add(d);

        d = m("gas_arriba_continuo", "Gas tóxico invisible",
            "ReviiL libera un gas tóxico invisible en todas las dimensiones. Durante este evento, todos deben permanecer por encima de la capa 250 o recibirán daño continuo hasta morir.", 180);
        d.objective = "above"; d.objectiveY = 250; d.objectiveMode = "during"; d.failAction = "gas";
        d.durationSeconds = 240; d.delaySeconds = 45;
        d.objectiveText = "&fPermanece por encima de la capa %y%";
        l.add(d);

        // ---------------- reglas ----------------
        d = m("posiciones_intercambiadas", "Posiciones intercambiadas",
            "¡ReviiL lanzó un conjuro con la Ruleta para intercambiar aleatoriamente las posiciones de todos los humanos!", 5);
        d.swapPositions = true; d.showTimer = false;
        l.add(d);

        d = m("sin_regeneracion", "Sin regeneración natural",
            "ReviiL lanzó un conjuro con la Ruleta. Hasta que termine el contador no se puede regenerar vida de manera natural.", 300);
        d.noRegen = true; d.objectiveText = "&fSin regeneración natural";
        l.add(d);

        d = m("vida_oculta", "Vida oculta",
            "ReviiL lanzó un conjuro con la Ruleta. Hasta que termine el contador no podrán ver su vida.", 300);
        d.hideHealth = true; d.objectiveText = "&fVida oculta";
        l.add(d);

        d = m("ceguera", "Ceguera",
            "ReviiL lanzó un conjuro con la Ruleta y dio ceguera por unos momentos.", 20);
        d.blindnessSeconds = 20; d.showTimer = false;
        l.add(d);

        // ---------------- bunker / rayo mortal ----------------
        d = m("bunker", "Refugiarse en el Bunker",
            "¡ReviiL nos está observando y quiere lanzar un rayo mortal! Eón construyó un Búnker para refugiarnos. Antes de que termine el temporizador TODOS deben estar DENTRO o morirán. Diríjanse a %bunker%.", 180);
        d.objective = "bunker"; d.failAction = "lightning"; d.bunkerParticles = true;
        l.add(d);

        d = m("rayo_mortal", "Rayo mortal",
            "¡ReviiL nos está observando y quiere lanzar un rayo mortal! Antes de que termine el contador TODOS deben estar dentro y TOCAR la zona segura (partículas azules), o morirán. Diríjanse a %bunker%.", 180);
        d.objective = "bunker"; d.failAction = "lightning"; d.bunkerParticles = true;
        l.add(d);

        d = m("nether_desactivado", "Refugio y Nether desactivado",
            "¡ReviiL ha DESACTIVADO el Nether! Eón ha creado un refugio para resistir. Deben llegar antes de que termine el tiempo… o morirán. Diríjanse a %bunker%.", 300);
        d.objective = "bunker"; d.failAction = "lightning"; d.bunkerParticles = true; d.disableNether = true;
        l.add(d);

        d = m("agujeros_negros", "Agujeros Negros",
            "¡No puede ser! ¡ReviiL creó Agujeros Negros! Bajan y crecen cada vez más, absorben los bloques y jalan a quien esté afuera. Debemos llegar al Búnker antes de que termine el contador: al llegar al nivel 10 absorben a todos los que no estén dentro. El Nether ha sido desactivado. Diríjanse a %bunker%.", 240);
        d.objective = "bunker"; d.failAction = "absorb"; d.bunkerParticles = true; d.disableNether = true;
        d.blackHoles = 3; d.blackHoleRadius = 22f; d.blackHoleGrowth = 2.2f; d.blackHoleAbsorb = true; d.delaySeconds = 15;
        l.add(d);

        // ---------------- creepers electricos ----------------
        d = m("creepers_electricos", "Creepers Eléctricos",
            "¡ReviiL lanzó un conjuro con la Ruleta! Aleatoriamente y en cualquier momento aparecerán Creepers Eléctricos con 1 de vida en tu posición." + ACUM, 180);
        d.creeperMode = "electric"; d.creeperHealth = 1f; d.creeperEvents = 4;
        d.objectiveText = "&fCuidado: Creepers Eléctricos";
        l.add(d);

        d = m("lluvia_creepers", "Lluvia de Creepers Eléctricos",
            "¡ReviiL está haciendo llover Creepers Eléctricos! En un momento aleatorio y en más de una ocasión, puede aparecer un Creeper Eléctrico con 1 de vida en tu posición.", 120);
        d.creeperMode = "electric"; d.creeperHealth = 1f; d.creeperEvents = 10;
        d.objectiveText = "&fLluvia de Creepers Eléctricos";
        l.add(d);

        d = m("creepers_evolucionados", "Creepers Eléctricos Evolucionados",
            "¡Los Creepers han evolucionado con la Luna! En cualquier momento y de manera aleatoria aparecerán Creepers Eléctricos con 20 de vida.", 180);
        d.creeperMode = "electric"; d.creeperHealth = 20f; d.creeperEvents = 4;
        d.objectiveText = "&fCreepers Eléctricos evolucionados";
        l.add(d);

        d = m("cualquier_creeper", "Cualquier tipo de Creeper",
            "En cualquier momento y de manera aleatoria aparecerá CUALQUIER TIPO DE CREEPER en tu posición.", 180);
        d.creeperMode = "any"; d.creeperHealth = 20f; d.creeperEvents = 4;
        d.objectiveText = "&fCualquier tipo de Creeper";
        l.add(d);

        d = m("ceguera_creepers", "Ceguera y Creepers Eléctricos",
            "ReviiL lanzó un conjuro con la Ruleta y dio ceguera por unos momentos. Además, en un momento aleatorio puede aparecer un Creeper Eléctrico con 1 de vida en tu posición.", 180);
        d.blindnessSeconds = 20; d.creeperMode = "electric"; d.creeperEvents = 4;
        d.objectiveText = "&fCeguera y Creepers Eléctricos";
        l.add(d);

        d = m("posiciones_creepers", "Posiciones intercambiadas y Creepers Eléctricos",
            "¡ReviiL intercambió aleatoriamente las posiciones de todos los humanos! Además, en un momento aleatorio puede aparecer un Creeper Eléctrico con 1 de vida en tu posición.", 180);
        d.swapPositions = true; d.creeperMode = "electric"; d.creeperEvents = 4;
        d.objectiveText = "&fCreepers Eléctricos";
        l.add(d);

        d = m("vida_oculta_creepers", "Vida oculta y Creepers Eléctricos",
            "Hasta que termine el contador no podrán ver su vida. Además, en un momento aleatorio puede aparecer un Creeper Eléctrico con 1 de vida en tu posición.", 180);
        d.hideHealth = true; d.creeperMode = "electric"; d.creeperEvents = 4;
        d.objectiveText = "&fVida oculta y Creepers Eléctricos";
        l.add(d);

        // ---------------- eclipse / luna ----------------
        d = m("eclipse", "Eclipse Solar",
            "El Eclipse se acerca. Les recomendamos mantenerse en la superficie y NO ir bajo tierra. Desconocemos los efectos del Eclipse.", 300);
        d.forceTime = 6000; d.eclipseShader = true; d.objectiveText = "&fEclipse Solar";
        l.add(d);

        d = m("eclipse_herobrine", "Eclipse y Herobrine",
            "¡Ha llegado el Eclipse! Deben utilizar linternas (Linterna del mod) para abrirse paso por el mundo. CUIDADO: Herobrine está entre nosotros. NO lo mires a los ojos o te atacará y te hará mucho daño. Puedes apuntarle con la Linterna para que desaparezca.", 300);
        d.forceTime = 6000; d.eclipseShader = true; d.herobrine = true; d.herobrineCount = 1;
        d.objectiveText = "&fEclipse: no mires a Herobrine";
        l.add(d);

        d = m("luna_de_sangre", "Luna de Sangre",
            "¡Está a punto de comenzar una Luna de Sangre! Todos los jugadores deben estar en sus bases al finalizar el contador.", 180);
        d.forceTime = 18000; d.objective = "base"; d.failAction = "gas";
        l.add(d);

        d = m("luna_sangre_creepers", "Luna de Sangre y Creepers Eléctricos",
            "¡Ha iniciado una Luna de Sangre! En cualquier momento y de manera aleatoria aparecerán Creepers Eléctricos con 1 de vida en tu posición. Todos deben estar en sus bases al finalizar el contador.", 180);
        d.forceTime = 18000; d.objective = "base"; d.failAction = "gas";
        d.creeperMode = "electric"; d.creeperEvents = 4;
        l.add(d);

        d = m("maldicion_luna", "Maldición de la Luna",
            "¡Vaya horrible noche para tener una maldición! El primer jugador en mirar a la Luna recibirá daño instantáneo y morirá. Este cambio permanecerá hasta que alguien muera por esa razón. Luego será desactivado.", 0);
        d.moonCurse = true; d.showTimer = false; d.objectiveText = "&cNo mires a la Luna";
        l.add(d);

        // ---------------- clima ----------------
        d = m("tormenta_electrica", "Tormenta eléctrica",
            "¡Se avecina una tormenta eléctrica! Cuidado con los rayos.", 180);
        d.thunderstorm = true; d.objectiveText = "&fTormenta eléctrica";
        l.add(d);

        // ---------------- agua ----------------
        d = m("bajo_agua", "Permanecer bajo el agua",
            "Tienen 5 minutos para meterse bajo el agua de CUALQUIER dimensión y sumergir su cuerpo POR COMPLETO. Quien no esté dentro del agua al finalizar el tiempo recibirá daño hasta morir. Para permanecer debajo del agua usen Pociones de Respiración Acuática.", 300);
        d.objective = "underwater"; d.failAction = "gas";
        l.add(d);

        d = m("creepers_bajo_agua", "Creepers bajo el Agua",
            "Deben permanecer bajo el agua SIN SALIR hasta que el tiempo termine. En cualquier momento puede aparecer un Creeper de CUALQUIER tipo. Recuerden sumergir TODA la hitbox.", 240);
        d.objective = "underwater"; d.objectiveMode = "during"; d.failAction = "gas";
        d.creeperMode = "any"; d.creeperHealth = 20f; d.creeperEvents = 4;
        l.add(d);

        // ---------------- supernovas ----------------
        d = m("supernova_alejarse", "Otra Supernova sobre el Búnker",
            "¡NO PUEDE SER! ReviiL ahora sabe dónde estamos y lanzó otra Supernova justo sobre el Búnker que estallará en poco tiempo. Deben alejarse lo antes posible. Una vez que estén suficientemente lejos pueden ver la Supernova.", 90);
        d.supernova = true; d.supernovaSafe = "none"; d.supernovaMaxRadius = 250f; d.supernovaSpeed = 90f;
        d.objectiveText = "&fAléjate de la supernova";
        l.add(d);

        d = m("supernova_bunker", "Supernova sobre el Búnker",
            "¡IMPOSIBLE! ¡ReviiL ha encontrado nuestra localización y lanzó una supernova justo sobre el Búnker! Estallará en poco tiempo. ¡Debemos llegar al otro Búnker cuanto antes! Diríjanse a %bunker%. Los portales al Nether no funcionan.", 120);
        d.supernova = true; d.supernovaSafe = "bunker"; d.supernovaMaxRadius = 400f; d.supernovaSpeed = 80f;
        d.bunkerParticles = true; d.disableNether = true;
        l.add(d);

        d = m("gran_supernova", "Gran Supernova y Onda Expansiva",
            "¡ReviiL encontró la forma de invertir la entropía de los Agujeros Negros y los juntó, convirtiéndolos en una Gran Supernova! Aléjense lo más que puedan del lugar. CUIDADO: la onda expansiva podría alcanzar a todo el mundo.", 90);
        d.supernova = true; d.supernovaSafe = "none"; d.supernovaMaxRadius = 2000f; d.supernovaSpeed = 60f;
        d.objectiveText = "&fAléjate lo más que puedas";
        l.add(d);

        d = m("escape_dimension", "Escapar hacia otra dimensión",
            "¡Las Supernovas estallaron! Debemos escapar hacia otra dimensión ANTES QUE TERMINE EL TIEMPO, o la Onda Expansiva acabará con nosotros.", 120);
        d.supernova = true; d.supernovaSafe = "none"; d.supernovaMaxRadius = 100000f; d.supernovaSpeed = 100f;
        d.dimensions = new ArrayList<>(List.of("minecraft:overworld"));
        d.objectiveText = "&fEscapa a otra dimensión";
        l.add(d);

        // ---------------- aviso ----------------
        d = m("simulacro", "Simulacro de Emergencia",
            "Esto es un SIMULACRO. No hay Momento ReviiL (aún). Pero aun así deberían estar MUY atentos. Podría suceder en CUALQUIER momento.", 15);
        d.showTimer = false;
        l.add(d);

        // tiempo antes de que empiecen los efectos (ajustalo en moments.json o por comando)
        for (MomentDef x : l) {
            switch (x.id) {
                case "eclipse_herobrine" -> x.delaySeconds = 20;
                case "tormenta_electrica" -> x.delaySeconds = 10;
                case "creepers_bajo_agua" -> x.delaySeconds = 30;
                default -> { }
            }
        }
        return l;
    }
}
