package com.example.revil;

import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Herobrine.
 *  - ACECHO: camina en silencio y despacio hacia el jugador mas cercano (si esta muy lejos se acerca de golpe).
 *  - FURIA: si un jugador lo mira a los ojos (formula del Enderman) corre hacia el, golpea con mucho dano
 *    y NO SE DEJA ESCAPAR: si no puede llegar (te subiste a un pilar, al techo, agua...) se teletransporta
 *    pegado a ti y te golpea; si estas lejos, aparece cerca.
 *  - LUZ: apuntarle con la linterna lo paraliza (no ataca ni se mueve) y a 1 s desaparece (lo gestiona RevilManager).
 *  - Invulnerable (solo creativo / comandos), pasos silenciosos, ojos brillantes (capa de render).
 */
public class HerobrineEntity extends Monster {
    public static final float DEFAULT_DAMAGE = 14.0f;

    private boolean aggro = false;
    private UUID targetId = null;
    private int attackCooldown = 0;
    private int blinkCooldown = 60;
    private int retargetCooldown = 0;
    private int stuckTicks = 0;
    private int beamTicks = 0;
    private double lastDist = 1.0e9;

    public HerobrineEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
            .add(Attributes.MAX_HEALTH, 200.0)
            .add(Attributes.MOVEMENT_SPEED, 0.30)
            .add(Attributes.ATTACK_DAMAGE, DEFAULT_DAMAGE)
            .add(Attributes.FOLLOW_RANGE, 96.0)
            .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
    }

    /** La luz de la linterna lo paraliza unos instantes (lo llama RevilManager mientras lo apuntan). */
    public void beam() {
        this.beamTicks = 6;
    }

    // ------------------------------------------------------------------ IA

    private static boolean valid(Player p) {
        return p.isAlive() && !p.isSpectator() && !p.isCreative() && !p.getTags().contains("revil_exempt");
    }

    private Player playerById(UUID id) {
        return id == null ? null : this.level().getPlayerByUUID(id);
    }

    private Player nearestPlayer() {
        Player best = null;
        double bestD = Double.MAX_VALUE;
        for (Player p : this.level().players()) {
            if (!valid(p)) continue;
            double d = this.distanceToSqr(p);
            if (d < bestD && d < 160.0 * 160.0) {
                bestD = d;
                best = p;
            }
        }
        return best;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) return;

        if (attackCooldown > 0) attackCooldown--;
        if (blinkCooldown > 0) blinkCooldown--;
        if (retargetCooldown > 0) retargetCooldown--;

        // paralizado por la luz de la linterna
        if (beamTicks > 0) {
            beamTicks--;
            this.getNavigation().stop();
            return;
        }

        // 1) mirada a los ojos -> furia contra quien lo mira
        if (this.tickCount % 3 == 0) {
            for (Player p : this.level().players()) {
                if (valid(p) && isLookedAtBy(p)) {
                    enrage(p);
                    break;
                }
            }
        }

        // 2) objetivo actual
        Player target = playerById(targetId);
        if (target == null || !valid(target) || target.level() != this.level()) {
            if (aggro) {
                aggro = false;                 // su victima murio o se fue: vuelve a acechar
                blinkCooldown = 60;
            }
            targetId = null;
            if (retargetCooldown <= 0) {
                Player n = nearestPlayer();
                targetId = n == null ? null : n.getUUID();
                retargetCooldown = 40;
            }
            target = playerById(targetId);
            if (target == null) {
                this.getNavigation().stop();
                return;
            }
        }

        this.getLookControl().setLookAt(target, 40.0F, 40.0F);
        double dist = Math.sqrt(this.distanceToSqr(target));

        if (aggro) aggroTick(target, dist);
        else stalkTick(target, dist);
    }

    private void stalkTick(Player target, double dist) {
        if (dist > 70.0 && blinkCooldown <= 0) {
            blinkAround(target, 34.0);          // se mantiene cerca de su presa
            blinkCooldown = 100;
        } else if (this.tickCount % 10 == 0) {
            this.getNavigation().moveTo(target, 0.55);   // acecho lento
        }
    }

    private void aggroTick(Player target, double dist) {
        if (inReach(target)) {
            stuckTicks = 0;
            if (attackCooldown <= 0) {
                this.swing(InteractionHand.MAIN_HAND);
                this.doHurtTarget(target);
                attackCooldown = 18;
            }
            return;
        }

        if (this.tickCount % 4 == 0) this.getNavigation().moveTo(target, 1.7);

        // progreso: si no se acerca en 1 segundo esta atorado (pilar, techo, agua, pared...)
        if (this.tickCount % 10 == 0) {
            if (dist > lastDist - 0.4) stuckTicks += 10;
            else stuckTicks = 0;
            lastDist = dist;
        }
        boolean noPath = this.getNavigation().isDone();

        if (blinkCooldown <= 0) {
            if (dist > 16.0) {
                blinkAround(target, 6.0);                       // lejos: aparece cerca
                blinkCooldown = 60;
            } else if (stuckTicks >= 20 || noPath) {
                if (blinkAdjacent(target)) {                    // no llega: aparece pegado a ti
                    blinkCooldown = 20;
                    stuckTicks = 0;
                }
            }
        }
    }

    /** Alcance generoso (incluye 3-4 bloques de desnivel) y con linea de vision. */
    private boolean inReach(Player target) {
        AABB reach = this.getBoundingBox().inflate(1.6, 1.8, 1.6);
        return reach.intersects(target.getBoundingBox()) && this.hasLineOfSight(target);
    }

    private void enrage(Player p) {
        if (aggro && p.getUUID().equals(targetId)) return;
        aggro = true;
        targetId = p.getUUID();
        blinkCooldown = 40;
        stuckTicks = 0;
        if (this.level() instanceof ServerLevel lv) {
            RevilSounds.at(lv, this.getX(), this.getY(), this.getZ(), "entity.enderman.stare",
                SoundSource.HOSTILE, 2.5f, 0.5f);
        }
    }

    private void teleportSound() {
        if (this.level() instanceof ServerLevel lv) {
            RevilSounds.at(lv, this.getX(), this.getY(), this.getZ(), "entity.enderman.teleport",
                SoundSource.HOSTILE, 1.0f, 0.5f);
        }
    }

    /** Aparece en un anillo alrededor de la victima (usa el teletransporte seguro del Enderman). */
    private void blinkAround(Player target, double radius) {
        for (int i = 0; i < 8; i++) {
            double a = this.random.nextDouble() * Math.PI * 2;
            double x = target.getX() + Math.cos(a) * radius;
            double z = target.getZ() + Math.sin(a) * radius;
            if (this.randomTeleport(x, target.getY(), z, false)) {
                teleportSound();
                return;
            }
        }
    }

    /**
     * Aparece a 1.6-3.2 bloques de la victima en cualquier hueco libre (incluso en el aire, a su altura o mas abajo).
     * Asi no se escapa quien se sube a un pilar o al techo: aparece al lado y golpea.
     */
    private boolean blinkAdjacent(Player target) {
        for (int i = 0; i < 16; i++) {
            double a = this.random.nextDouble() * Math.PI * 2;
            double r = 1.6 + this.random.nextDouble() * 1.6;
            double x = target.getX() + Math.cos(a) * r;
            double z = target.getZ() + Math.sin(a) * r;
            for (int dy = 1; dy >= -2; dy--) {
                double y = target.getY() + dy;
                AABB box = this.getDimensions(this.getPose()).makeBoundingBox(x, y, z);
                if (this.level().noCollision(this, box) && !this.level().containsAnyLiquid(box)) {
                    this.moveTo(x, y, z, this.getYRot(), 0.0F);
                    this.getNavigation().stop();
                    teleportSound();
                    return true;
                }
            }
        }
        return false;
    }

    /** Misma formula que el Enderman: mirar su cabeza/ojos con linea de vision. */
    private boolean isLookedAtBy(Player p) {
        Vec3 look = p.getViewVector(1.0F).normalize();
        Vec3 to = new Vec3(this.getX() - p.getX(), this.getEyeY() - p.getEyeY(), this.getZ() - p.getZ());
        double dist = to.length();
        if (dist > 64.0 || dist < 0.5) return false;
        to = to.normalize();
        return look.dot(to) > 1.0 - 0.03 / dist && p.hasLineOfSight(this);
    }

    // ------------------------------------------------------------------ comportamiento general

    /** Invulnerable: solo le afectan el modo creativo y los danos "del vacio/kill". */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        Entity e = source.getEntity();
        if (e instanceof Player p && p.isCreative()) return super.hurt(source, amount);
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        return false;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        // pasos silenciosos
    }

    @Override
    protected boolean shouldDropLoot() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }
}
