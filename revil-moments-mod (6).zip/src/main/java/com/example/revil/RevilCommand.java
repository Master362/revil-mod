package com.example.revil;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = RevilMod.MODID)
public class RevilCommand {
    private static final SuggestionProvider<CommandSourceStack> MOMENTS =
        (ctx, b) -> SharedSuggestionProvider.suggest(RevilConfig.MOMENTS.keySet(), b);

    private static final SuggestionProvider<CommandSourceStack> ACTIVE =
        (ctx, b) -> {
            List<String> ids = new ArrayList<>();
            for (RevilManager.Run r : RevilManager.RUNS) ids.add(r.def.id);
            return SharedSuggestionProvider.suggest(ids, b);
        };

    private static final SuggestionProvider<CommandSourceStack> TIMES =
        (ctx, b) -> SharedSuggestionProvider.suggest(List.of("0", "30s", "1m", "2m", "3m", "5m", "10m"), b);

    private static final Pattern TIME = Pattern.compile("^(?:(\\d+)h)?(?:(\\d+)m)?(?:(\\d+)s)?$");

    /** "90", "30s", "2m", "1m30s", "1h" -> segundos. -1 si no es valido. */
    static int parseSeconds(String raw) {
        String s = raw.trim().toLowerCase();
        if (s.isEmpty()) return -1;
        if (s.matches("\\d+")) return Integer.parseInt(s);
        Matcher m = TIME.matcher(s);
        if (!m.matches()) return -1;
        int h = m.group(1) == null ? 0 : Integer.parseInt(m.group(1));
        int mi = m.group(2) == null ? 0 : Integer.parseInt(m.group(2));
        int se = m.group(3) == null ? 0 : Integer.parseInt(m.group(3));
        return h * 3600 + mi * 60 + se;
    }

    static String fmtTime(int secs) {
        if (secs <= 0) return "sin l\u00edmite";
        int h = secs / 3600, m = (secs % 3600) / 60, s = secs % 60;
        StringBuilder sb = new StringBuilder();
        if (h > 0) sb.append(h).append("h");
        if (m > 0) sb.append(m).append("m");
        if (s > 0 || sb.length() == 0) sb.append(s).append("s");
        return sb.toString();
    }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();

        d.register(Commands.literal("revil")
            .requires(s -> s.hasPermission(2))

            .then(Commands.literal("list").executes(RevilCommand::list))

            // /revil start <momento> [duracion] [retraso]     ej: /revil start gas_abajo 2m 10s
            //   duracion = tiempo total (0 = sin limite) | retraso = tiempo hasta que empiecen los efectos
            .then(Commands.literal("start")
                .then(Commands.argument("moment", StringArgumentType.word()).suggests(MOMENTS)
                    .executes(c -> start(c, null, null))
                    .then(Commands.argument("time", StringArgumentType.word()).suggests(TIMES)
                        .executes(c -> start(c, StringArgumentType.getString(c, "time"), null))
                        .then(Commands.argument("delay", StringArgumentType.word()).suggests(TIMES)
                            .executes(c -> start(c, StringArgumentType.getString(c, "time"),
                                StringArgumentType.getString(c, "delay")))))))

            // /revil stop [momento]   sin argumento = todos
            .then(Commands.literal("stop")
                .executes(c -> {
                    int n = RevilManager.stop(c.getSource().getServer(), null);
                    return msg(c, "Momentos cancelados: " + n + " (y gas / cadenas pendientes).");
                })
                .then(Commands.argument("moment", StringArgumentType.word()).suggests(ACTIVE)
                    .executes(c -> {
                        String id = StringArgumentType.getString(c, "moment");
                        int n = RevilManager.stop(c.getSource().getServer(), id);
                        if (n == 0) {
                            c.getSource().sendFailure(Component.literal("Ese momento no est\u00e1 activo."));
                            return 0;
                        }
                        return msg(c, "Momento '" + id + "' cancelado.");
                    })))

            .then(Commands.literal("status").executes(RevilCommand::status))

            .then(Commands.literal("reload").executes(c -> {
                RevilConfig.load();
                return msg(c, "Configuraci\u00f3n recargada: " + RevilConfig.MOMENTS.size() + " momentos.");
            }))

            // ---- bunker ----
            .then(Commands.literal("bunker")
                .then(Commands.literal("set")
                    .then(Commands.argument("x1", IntegerArgumentType.integer())
                        .then(Commands.argument("y1", IntegerArgumentType.integer())
                            .then(Commands.argument("z1", IntegerArgumentType.integer())
                                .then(Commands.argument("x2", IntegerArgumentType.integer())
                                    .then(Commands.argument("y2", IntegerArgumentType.integer())
                                        .then(Commands.argument("z2", IntegerArgumentType.integer())
                                            .executes(RevilCommand::bunkerSet))))))))
                .then(Commands.literal("here")
                    .then(Commands.argument("radius", IntegerArgumentType.integer(1, 500))
                        .executes(RevilCommand::bunkerHere)))
                .then(Commands.literal("clear").executes(c -> {
                    RevilData.get(c.getSource().getServer()).clearBunker();
                    return msg(c, "Bunker eliminado.");
                }))
                .then(Commands.literal("show").executes(c -> {
                    String s = RevilData.get(c.getSource().getServer()).describeBunker();
                    c.getSource().sendSuccess(() -> Component.literal("Bunker: " + s), false);
                    return 1;
                })))

            // ---- supernova: epicentro ----
            .then(Commands.literal("supernova")
                .then(Commands.literal("set").executes(c -> {
                    Vec3 p = c.getSource().getPosition();
                    String dim = c.getSource().getLevel().dimension().location().toString();
                    RevilData data = RevilData.get(c.getSource().getServer());
                    data.setNova(dim, p.x, p.y, p.z);
                    return msg(c, "Epicentro de la supernova fijado: " + data.describeNova());
                }))
                .then(Commands.literal("clear").executes(c -> {
                    RevilData.get(c.getSource().getServer()).clearNova();
                    return msg(c, "Epicentro eliminado (se usar\u00e1 el bunker o el spawn).");
                }))
                .then(Commands.literal("show").executes(c -> {
                    String s = RevilData.get(c.getSource().getServer()).describeNova();
                    c.getSource().sendSuccess(() -> Component.literal("Epicentro: " + s), false);
                    return 1;
                })))

            // ---- linterna ----
            .then(Commands.literal("flashlight")
                .executes(c -> giveFlashlight(c, c.getSource().getPlayerOrException()))
                .then(Commands.argument("target", EntityArgument.player())
                    .executes(c -> giveFlashlight(c, EntityArgument.getPlayer(c, "target")))))

            // ---- herobrine (pruebas) ----
            .then(Commands.literal("herobrine")
                .then(Commands.literal("spawn").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    UUID id = RevilManager.spawnHerobrine(p, HerobrineEntity.DEFAULT_DAMAGE);
                    if (id == null) {
                        c.getSource().sendFailure(Component.literal("No se encontr\u00f3 un lugar cargado cerca."));
                        return 0;
                    }
                    return msg(c, "Herobrine aparece a lo lejos y camina hacia ti. No lo mires a los ojos...");
                }))
                .then(Commands.literal("clear").executes(c -> {
                    int n = RevilManager.clearHerobrines(c.getSource().getServer());
                    return msg(c, "Herobrines eliminados: " + n);
                })))

            // ---- ajustes globales ----
            .then(Commands.literal("config")
                .then(flag("deadly", "Castigo real", v -> RevilConfig.deadly = v))
                .then(flag("totem", "T\u00f3tem salva del castigo", v -> RevilConfig.totemSaves = v))
                .then(flag("announce", "Aviso de t\u00edtulo/chat al iniciar un momento", v -> RevilConfig.announce = v))
                .then(flag("hud", "Cuenta atr\u00e1s y objetivo en pantalla", v -> RevilConfig.showHud = v))
                .then(flag("broadcast", "Mensaje en el chat cuando alguien falla", v -> RevilConfig.broadcastFails = v)))
        );
    }

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<CommandSourceStack> flag(
            String name, String label, java.util.function.Consumer<Boolean> setter) {
        return Commands.literal(name).then(Commands.argument("enabled", BoolArgumentType.bool())
            .executes(c -> {
                boolean v = BoolArgumentType.getBool(c, "enabled");
                setter.accept(v);
                RevilConfig.saveSettings();
                RevilManager.syncAll(c.getSource().getServer());
                return msg(c, label + ": " + v);
            }));
    }

    private static int giveFlashlight(CommandContext<CommandSourceStack> c, ServerPlayer p) {
        ItemStack st = new ItemStack(ModItems.FLASHLIGHT.get());
        if (!p.getInventory().add(st)) p.drop(st, false);
        return msg(c, "Linterna entregada a " + p.getGameProfile().getName() + ". Clic derecho para encenderla.");
    }

    private static int msg(CommandContext<CommandSourceStack> c, String text) {
        c.getSource().sendSuccess(() -> Component.literal(text), true);
        return 1;
    }

    private static int start(CommandContext<CommandSourceStack> c, String time, String delay) {
        String id = StringArgumentType.getString(c, "moment").toLowerCase();
        MomentDef def = RevilConfig.MOMENTS.get(id);
        if (def == null) {
            c.getSource().sendFailure(Component.literal("No existe el momento '" + id + "'. Usa /revil list."));
            return 0;
        }
        int secs = -1, del = -1;
        if (time != null) {
            secs = parseSeconds(time);
            if (secs < 0) {
                c.getSource().sendFailure(Component.literal("Tiempo inv\u00e1lido '" + time + "'. Ejemplos: 90, 30s, 2m, 1m30s (0 = sin l\u00edmite)."));
                return 0;
            }
        }
        if (delay != null) {
            del = parseSeconds(delay);
            if (del < 0) {
                c.getSource().sendFailure(Component.literal("Retraso inv\u00e1lido '" + delay + "'. Ejemplos: 0, 10s, 1m."));
                return 0;
            }
        }
        String err = RevilManager.start(c.getSource().getServer(), def, secs, del);
        if (err != null) {
            c.getSource().sendFailure(Component.literal(err));
            return 0;
        }
        int total = secs >= 0 ? secs : def.durationSeconds;
        int wait = del >= 0 ? del : def.delaySeconds;
        return msg(c, "Momento '" + id + "' iniciado: duraci\u00f3n " + fmtTime(total)
            + (wait > 0 ? ", efectos tras " + fmtTime(wait) : ", efectos inmediatos")
            + (RevilConfig.deadly ? "" : " [modo pruebas]"));
    }

    private static int list(CommandContext<CommandSourceStack> c) {
        for (MomentDef m : RevilConfig.MOMENTS.values()) {
            StringBuilder sb = new StringBuilder("- " + m.id + " (" + fmtTime(m.durationSeconds));
            if (m.delaySeconds > 0) sb.append(", efectos tras ").append(fmtTime(m.delaySeconds));
            sb.append(")");
            if (!m.objective.equalsIgnoreCase("none")) sb.append(" objetivo=").append(m.objective);
            if (!m.creeperMode.equalsIgnoreCase("none")) sb.append(" creepers");
            if (m.herobrine) sb.append(" herobrine");
            if (!m.then.isEmpty()) sb.append(" -> ").append(m.then);
            String line = sb.toString();
            c.getSource().sendSuccess(() -> Component.literal(line), false);
        }
        return RevilConfig.MOMENTS.size();
    }

    private static int status(CommandContext<CommandSourceStack> c) {
        RevilData data = RevilData.get(c.getSource().getServer());
        String cfg = " | castigo real=" + RevilConfig.deadly + " aviso=" + RevilConfig.announce
            + " hud=" + RevilConfig.showHud;
        String text;
        if (RevilManager.RUNS.isEmpty()) {
            text = "Sin momentos activos" + cfg + " | bunker: " + data.describeBunker();
        } else {
            StringBuilder sb = new StringBuilder("Activos: ");
            for (RevilManager.Run r : RevilManager.RUNS) {
                sb.append(r.def.id);
                if (!r.activated) sb.append(" [espera ").append(Math.max(0, r.delayTicks - r.age) / 20).append("s]");
                sb.append(r.indefinite() ? " (sin l\u00edmite) " : " (" + Math.max(0, r.left) / 20 + "s) ");
            }
            text = sb.append(cfg).toString();
        }
        c.getSource().sendSuccess(() -> Component.literal(text), false);
        return 1;
    }

    private static int bunkerSet(CommandContext<CommandSourceStack> c) {
        String dim = c.getSource().getLevel().dimension().location().toString();
        RevilData data = RevilData.get(c.getSource().getServer());
        data.setBunker(dim,
            IntegerArgumentType.getInteger(c, "x1"), IntegerArgumentType.getInteger(c, "y1"),
            IntegerArgumentType.getInteger(c, "z1"), IntegerArgumentType.getInteger(c, "x2"),
            IntegerArgumentType.getInteger(c, "y2"), IntegerArgumentType.getInteger(c, "z2"));
        return msg(c, "Bunker fijado: " + data.describeBunker());
    }

    private static int bunkerHere(CommandContext<CommandSourceStack> c) {
        int r = IntegerArgumentType.getInteger(c, "radius");
        Vec3 p = c.getSource().getPosition();
        int x = (int) Math.floor(p.x), y = (int) Math.floor(p.y), z = (int) Math.floor(p.z);
        String dim = c.getSource().getLevel().dimension().location().toString();
        RevilData data = RevilData.get(c.getSource().getServer());
        data.setBunker(dim, x - r, y - r, z - r, x + r, y + r, z + r);
        return msg(c, "Bunker fijado alrededor de ti: " + data.describeBunker());
    }
}
