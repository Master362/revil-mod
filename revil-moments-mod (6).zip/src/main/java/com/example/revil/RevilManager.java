package com.example.revil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityTravelToDimensionEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Vector3f;

/**
 * Logica del servidor. Los momentos son ACUMULATIVOS (varios activos a la vez).
 *
 * Linea de tiempo de cada momento:
 *   [0 .. delaySeconds)            espera: todavia no hay efectos
 *   [delaySeconds .. duration)     los efectos estan activos
 *   duration                       fin: se evalua el objetivo (modo "end"), se aplica el castigo y explota la supernova
 */
@Mod.EventBusSubscriber(modid = RevilMod.MODID)
public class RevilManager {
    private static final RandomSource RNG = RandomSource.create();

    public static final List<Run> RUNS = new ArrayList<>();
    private static final List<Chain> CHAINS = new ArrayList<>();
    private static final List<Gas> GAS = new ArrayList<>();
    private static final List<Nova> NOVAS = new ArrayList<>();
    private static final List<Absorb> ABSORBING = new ArrayList<>();
    private static final Map<UUID, Integer> LANTERN_HITS = new HashMap<>();
    /** Jugadores que incumplieron un objetivo "during" hace poco (para el shader de gas). uuid -> tick de expiracion. */
    private static final Map<UUID, Integer> VIOLATORS = new HashMap<>();

    // bloqueos compartidos entre momentos (regeneracion y hora)
    private static int regenLocks = 0;
    private static boolean savedRegen = true;
    private static int timeLocks = 0;
    private static long savedTime = 0L, lockStartTick = 0L;
    private static boolean savedDaylight = true;

    public static class Run {
        public final MomentDef def;
        public final int total;
        public final int delayTicks;
        public int left;
        public int age = 0;
        public boolean activated = false;
        final Set<Integer> creeperTicks = new HashSet<>();
        final List<UUID> herobrines = new ArrayList<>();
        boolean prevRaining, prevThundering;
        // agujeros negros
        final List<Hole> holes = new ArrayList<>();
        String holeDim = "minecraft:overworld";
        double level = 0.0;                 // 0..10
        // supernova
        double[] novaPos = null;
        String novaDim = "minecraft:overworld";

        Run(MomentDef def, int ticks, int delayTicks) {
            this.def = def;
            this.total = ticks;
            this.left = ticks;
            this.delayTicks = delayTicks;
        }

        public boolean indefinite() {
            return total <= 0;
        }

        /** Progreso 0..1 desde que empiezan los efectos hasta el final. */
        double progress() {
            int active = indefinite() ? 1200 : Math.max(1, total - delayTicks);
            return Mth.clamp((age - delayTicks) / (double) active, 0.0, 1.0);
        }
    }

    private static class Chain {
        final String id;
        int delay;

        Chain(String id, int delay) {
            this.id = id;
            this.delay = delay;
        }
    }

    /** Jugador con dano continuo (gas) hasta que cumpla la condicion o muera. El dano sube con el tiempo. */
    private static class Gas {
        final UUID uuid;
        final MomentDef def;
        int seconds = 0;

        Gas(UUID uuid, MomentDef def) {
            this.uuid = uuid;
            this.def = def;
        }
    }

    /** Agujero negro: baja de (sx,sy,sz) a (ex,ey,ez) a lo largo del momento y crece. */
    private static class Hole {
        double sx, sy, sz, ex, ey, ez;
        double x, y, z;
        float baseRadius, radius;
    }

    /** Bloque que esta siendo succionado hacia un agujero negro. */
    private static class Absorb {
        final UUID id;
        final Run run;
        final int hole;

        Absorb(UUID id, Run run, int hole) {
            this.id = id;
            this.run = run;
            this.hole = hole;
        }
    }

    /** Supernova ya explotada: onda expansiva que se extiende desde el epicentro (y crater opcional). */
    private static class Nova {
        final MomentDef def;
        final String dim;
        final double x, y, z;
        int age = 0;
        final Set<UUID> hit = new HashSet<>();
        final List<int[]> columns = new ArrayList<>();
        int craterIdx = 0;

        Nova(MomentDef def, String dim, double x, double y, double z) {
            this.def = def;
            this.dim = dim;
            this.x = x;
            this.y = y;
            this.z = z;
            int r = (int) def.supernovaCrater;
            if (r > 0) {
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (dx * dx + dz * dz <= r * r) columns.add(new int[]{dx, dz});
                    }
                }
                columns.sort(Comparator.comparingInt(c -> c[0] * c[0] + c[1] * c[1]));
            }
        }

        double radius() {
            return age * (double) def.supernovaSpeed / 20.0;
        }
    }

    // ------------------------------------------------------------------ utilidades

    public static String fmt(String s) {
        return s.replace('&', '\u00a7');
    }

    static void send(ServerPlayer p, Object pkt) {
        Network.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt);
    }

    private static String dimOf(ServerPlayer p) {
        return p.level().dimension().location().toString();
    }

    private static ServerLevel levelOf(MinecraftServer server, String dim) {
        return server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(dim)));
    }

    private static List<String> dims(MomentDef d) {
        return (d.dimensions != null && !d.dimensions.isEmpty()) ? d.dimensions : RevilConfig.dimensions;
    }

    private static boolean eligible(ServerPlayer p) {
        if (!p.isAlive() || p.isSpectator() || p.isCreative()) return false;
        return !p.getTags().contains("revil_exempt");
    }

    private static List<ServerPlayer> affected(MinecraftServer server, MomentDef d) {
        List<ServerPlayer> list = new ArrayList<>();
        List<String> dl = dims(d);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (eligible(p) && dl.contains(dimOf(p))) list.add(p);
        }
        return list;
    }

    /** Sustituye %bunker% y %y%. */
    private static String ph(String s, RevilData data, MomentDef d) {
        return s.replace("%bunker%", data.center()).replace("%y%", String.valueOf(d.objectiveY));
    }

    public static String objectiveLine(MomentDef d) {
        if (!d.objectiveText.isEmpty()) return d.objectiveText;
        return switch (d.objective.toLowerCase()) {
            case "bunker" -> "&fRef\u00fagiate en el b\u00fanker (%bunker%)";
            case "above" -> "&fSube por encima de la capa %y%";
            case "below" -> "&fDesciende hasta la capa %y%";
            case "underwater" -> "&fSum\u00e9rgete por completo";
            case "base" -> "&fVuelve a tu base";
            default -> "";
        };
    }

    private static void runCommand(MinecraftServer server, String cmd) {
        String c = cmd.startsWith("/") ? cmd.substring(1) : cmd;
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), c);
    }

    private static Entity findEntity(MinecraftServer server, UUID id) {
        for (ServerLevel lv : server.getAllLevels()) {
            Entity e = lv.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    private static void info(ServerPlayer p, String text) {
        if (RevilConfig.announce) p.sendSystemMessage(Component.literal(text));
    }

    private static boolean needsBunker(MomentDef d) {
        return d.objective.equalsIgnoreCase("bunker")
            || (d.supernova && d.supernovaSafe.equalsIgnoreCase("bunker"));
    }

    // ------------------------------------------------------------------ ciclo de vida

    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent e) {
        RevilConfig.load();
        resetState();
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent e) {
        MinecraftServer server = e.getServer();
        // los bloques succionados no deben quedar flotando en el mundo guardado
        for (Absorb a : ABSORBING) {
            Entity en = findEntity(server, a.id);
            if (en != null) en.discard();
        }
        ABSORBING.clear();
        // devuelve gamerules/hora/clima antes de guardar el mundo
        for (Run r : new ArrayList<>(RUNS)) cleanup(server, r);
        RUNS.clear();
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        resetState();
    }

    private static void resetState() {
        RUNS.clear();
        CHAINS.clear();
        GAS.clear();
        NOVAS.clear();
        ABSORBING.clear();
        LANTERN_HITS.clear();
        VIOLATORS.clear();
        regenLocks = 0;
        timeLocks = 0;
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) send(sp, buildState(sp));
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) send(sp, buildState(sp));
    }

    /** Nether desactivado mientras haya un momento activo con disableNether. */
    @SubscribeEvent
    public static void onTravel(EntityTravelToDimensionEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (e.getDimension() != Level.NETHER) return;
        for (Run r : RUNS) {
            if (r.activated && r.def.disableNether && dims(r.def).contains(dimOf(p))) {
                e.setCanceled(true);
                if (RevilConfig.announce) {
                    p.displayClientMessage(Component.literal("\u00a7cEl Nether est\u00e1 desactivado por ReviiL."), true);
                }
                return;
            }
        }
    }

    // ------------------------------------------------------------------ iniciar / parar

    /**
     * @param seconds duracion total en segundos (-1 = la del momento, 0 = sin limite)
     * @param delay   segundos hasta que empiezan los efectos (-1 = el del momento)
     * @return null si salio bien, o el mensaje de error
     */
    public static String start(MinecraftServer server, MomentDef d, int seconds, int delay) {
        RevilData data = RevilData.get(server);
        if (needsBunker(d) && !data.hasBunker) {
            return "Este momento usa el bunker y no hay ninguno configurado: /revil bunker set ... o /revil bunker here <radio>";
        }
        for (Run r : RUNS) {
            if (r.def.id.equalsIgnoreCase(d.id)) return "Ese momento ya est\u00e1 activo.";
        }
        int secs = seconds >= 0 ? seconds : d.durationSeconds;
        int del = delay >= 0 ? delay : d.delaySeconds;
        if (secs > 0 && del >= secs) del = Math.max(0, secs - 1);   // el retraso nunca se pasa de la duracion

        Run r = new Run(d, Math.max(0, secs) * 20, del * 20);
        RUNS.add(r);
        announce(server, d, data);
        if (r.delayTicks <= 0) activate(server, r);
        syncAll(server);
        return null;
    }

    /** Termina un momento (o todos si id es null) sin castigar ni encadenar; tambien detiene supernovas en curso. */
    public static int stop(MinecraftServer server, String id) {
        int n = 0;
        for (Run r : new ArrayList<>(RUNS)) {
            if (id == null || r.def.id.equalsIgnoreCase(id)) {
                endRun(server, r, false, false);
                n++;
            }
        }
        if (id == null) {
            GAS.clear();
            CHAINS.clear();
            NOVAS.clear();
        } else {
            GAS.removeIf(g -> g.def.id.equalsIgnoreCase(id));
            NOVAS.removeIf(nv -> nv.def.id.equalsIgnoreCase(id));
        }
        syncAll(server);
        return n;
    }

    /** Aviso opcional (titulo + chat + sonido). Apagado por defecto. */
    private static void announce(MinecraftServer server, MomentDef d, RevilData data) {
        if (!RevilConfig.announce) return;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!dims(d).contains(dimOf(p))) continue;
            if (!d.title.isEmpty() || !d.name.isEmpty()) {
                p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 20));
                if (!d.name.isEmpty()) {
                    p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(fmt(ph(d.name, data, d)))));
                }
                p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(fmt(d.title))));
            }
            if (!d.description.isEmpty()) {
                p.sendSystemMessage(Component.literal(fmt("&c<ReviiL> &f" + ph(d.description, data, d))));
            }
            for (String line : d.messages) p.sendSystemMessage(Component.literal(fmt(ph(line, data, d))));
            if (d.sounds) RevilSounds.toPlayer(p, "entity.wither.spawn", 0.35f, 0.5f);
        }
    }

    /** Momento en que terminan la espera y empiezan los efectos. */
    private static void activate(MinecraftServer server, Run r) {
        r.activated = true;
        MomentDef d = r.def;
        List<ServerPlayer> aff = affected(server, d);

        if (d.blindnessSeconds > 0) {
            for (ServerPlayer p : aff) {
                p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, d.blindnessSeconds * 20, 0, false, false));
            }
        }
        if (d.swapPositions) swap(aff);
        if (d.noRegen) lockRegen(server);
        if (d.forceTime >= 0) lockTime(server, d.forceTime);

        if (d.thunderstorm) {
            ServerLevel ow = server.overworld();
            r.prevRaining = ow.isRaining();
            r.prevThundering = ow.isThundering();
            int remaining = r.indefinite() ? 6000 : Math.max(200, r.total - r.age);
            ow.setWeatherParameters(0, remaining + 200, true, true);
        }

        if (d.creeperEvents > 0 && !d.creeperMode.equalsIgnoreCase("none")) {
            int active = r.indefinite() ? 1200 : Math.max(0, r.total - r.delayTicks);
            int span = Math.max(40, active - 200);
            for (int i = 0; i < d.creeperEvents; i++) r.creeperTicks.add(r.age + 100 + RNG.nextInt(span));
        }

        if (d.herobrine) {
            for (int i = 0; i < Math.max(1, d.herobrineCount); i++) {
                if (aff.isEmpty()) break;
                UUID id = spawnHerobrine(aff.get(RNG.nextInt(aff.size())), d.herobrineDamage);
                if (id != null) r.herobrines.add(id);
            }
        }

        if (d.blackHoles > 0) placeHoles(server, r);
        if (d.supernova) placeNova(server, r);
        syncAll(server);
    }

    // ------------------------------------------------------------------ sincronizacion

    public static void syncAll(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) send(p, buildState(p));
    }

    /** Intensidad (0..1) del shader de gas para este jugador. */
    private static float gasLevel(ServerPlayer p) {
        float level = 0f;
        for (Gas g : GAS) {
            if (g.uuid.equals(p.getUUID())) level = Math.max(level, Math.min(1f, 0.35f + 0.08f * g.seconds));
        }
        MinecraftServer server = p.getServer();
        Integer until = VIOLATORS.get(p.getUUID());
        if (until != null && server != null && until > server.getTickCount()) level = Math.max(level, 0.6f);
        return level;
    }

    private static StatePacket buildState(ServerPlayer p) {
        List<StatePacket.Entry> list = new ArrayList<>();
        boolean hide = false;
        float eclipse = 0f;
        List<double[]> holes = new ArrayList<>();
        double[] nova = null;
        MinecraftServer server = p.getServer();
        RevilData data = server != null ? RevilData.get(server) : new RevilData();
        String pdim = dimOf(p);

        for (Run r : RUNS) {
            if (!dims(r.def).contains(pdim)) continue;
            if (r.activated) {
                if (r.def.hideHealth) hide = true;
                if (r.def.eclipseShader) eclipse = 1f;
                if (!r.holes.isEmpty() && pdim.equals(r.holeDim)) {
                    for (Hole h : r.holes) holes.add(new double[]{h.x, h.y, h.z, h.radius});
                }
                if (nova == null && r.def.supernova && r.novaPos != null && pdim.equals(r.novaDim)) {
                    nova = new double[]{r.novaPos[0], r.novaPos[1], r.novaPos[2], r.def.supernovaHeight,
                        r.progress(), 0.0, 0.0, r.def.supernovaSpeed, r.def.supernovaMaxRadius};
                }
            }
            if (!RevilConfig.showHud) continue;                       // HUD apagado: no se manda nada que mostrar
            String text = ph(objectiveLine(r.def), data, r.def);
            boolean timer = r.def.showTimer && !r.indefinite();
            if (!text.isEmpty() || timer) {
                list.add(new StatePacket.Entry(fmt(text), Math.max(0, r.left), r.total, timer));
            }
        }
        for (Nova n : NOVAS) {      // una supernova ya explotada tiene prioridad visual
            if (pdim.equals(n.dim) && dims(n.def).contains(pdim)) {
                nova = new double[]{n.x, n.y, n.z, n.def.supernovaHeight, 1.0, 1.0, n.age,
                    n.def.supernovaSpeed, n.def.supernovaMaxRadius};
                break;
            }
        }
        return new StatePacket(hide, list, eclipse, gasLevel(p), holes, nova);
    }

    // ------------------------------------------------------------------ tick

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = e.getServer();
        int tc = server.getTickCount();

        tickChains(server);
        if (tc % 20 == 0) tickGas(server);
        tickNovas(server);
        tickAbsorbing(server);
        if (tc % 10 == 0 && (!RUNS.isEmpty() || !GAS.isEmpty() || !NOVAS.isEmpty())) syncAll(server);
        if (RUNS.isEmpty()) return;

        for (Run r : new ArrayList<>(RUNS)) tickRun(server, r);
        if (tc % 2 == 0) tickLantern(server);
    }

    private static void tickRun(MinecraftServer server, Run r) {
        MomentDef d = r.def;
        r.age++;
        if (!r.indefinite()) r.left--;

        if (!r.activated && r.age >= r.delayTicks) activate(server, r);

        // el contorno azul del bunker se ve desde el principio (para que puedan llegar durante la espera)
        if (d.bunkerParticles && r.age % 10 == 0) bunkerParticles(server);

        if (r.activated) {
            if (r.creeperTicks.contains(r.age)) spawnCreepers(server, d);
            if (d.thunderstorm && r.age % Math.max(20, d.lightningIntervalSeconds * 20) == 0) strikeNearPlayer(server, d);
            if (d.moonCurse && r.age % 5 == 0 && checkMoon(server, r)) return;
            if (!d.objective.equalsIgnoreCase("none") && d.objectiveMode.equalsIgnoreCase("during") && r.age % 20 == 0) {
                damageViolators(server, r);
            }
            if (!r.holes.isEmpty()) tickHoles(server, r);
            if (d.supernova && d.sounds && r.age % 60 == 0) supernovaAmbient(server, r);
        }

        if (!r.indefinite() && r.left <= 0) endRun(server, r, true, true);
    }

    private static void tickChains(MinecraftServer server) {
        Iterator<Chain> it = CHAINS.iterator();
        List<String> toStart = new ArrayList<>();
        while (it.hasNext()) {
            Chain c = it.next();
            if (--c.delay <= 0) {
                toStart.add(c.id);
                it.remove();
            }
        }
        for (String id : toStart) {
            MomentDef def = RevilConfig.MOMENTS.get(id.toLowerCase());
            if (def != null) start(server, def, -1, -1);
        }
    }

    // ------------------------------------------------------------------ final del momento

    private static void endRun(MinecraftServer server, Run r, boolean evaluate, boolean chain) {
        RUNS.remove(r);
        cleanup(server, r);
        MomentDef d = r.def;

        // la supernova EXPLOTA al terminar el tiempo (no si se cancela con /revil stop)
        if (evaluate && d.supernova && r.novaPos != null) {
            NOVAS.add(new Nova(d, r.novaDim, r.novaPos[0], r.novaPos[1], r.novaPos[2]));
        }
        if (evaluate) evaluate(server, r);
        if (!d.endCommand.isBlank()) runCommand(server, d.endCommand);
        if (chain && !d.then.isBlank()) CHAINS.add(new Chain(d.then, Math.max(1, d.thenDelaySeconds * 20)));
        syncAll(server);
    }

    private static void cleanup(MinecraftServer server, Run r) {
        MomentDef d = r.def;
        if (r.activated) {
            if (d.noRegen) unlockRegen(server);
            if (d.forceTime >= 0) unlockTime(server);
            if (d.thunderstorm) {
                ServerLevel ow = server.overworld();
                if (r.prevRaining || r.prevThundering) ow.setWeatherParameters(0, 6000, r.prevRaining, r.prevThundering);
                else ow.setWeatherParameters(12000, 0, false, false);
            }
        }
        for (UUID id : r.herobrines) {
            Entity h = findEntity(server, id);
            if (h != null) h.discard();
            LANTERN_HITS.remove(id);
        }
        r.herobrines.clear();
        r.holes.clear();      // los bloques en vuelo se eliminan en tickAbsorbing
    }

    private static void evaluate(MinecraftServer server, Run r) {
        MomentDef d = r.def;
        RevilData data = RevilData.get(server);
        boolean has = !d.objective.equalsIgnoreCase("none");
        boolean end = d.objectiveMode.equalsIgnoreCase("end");
        for (ServerPlayer p : affected(server, d)) {
            if (has && end && !objectiveMet(p, d, data)) {
                fail(server, p, d, failReason(d));
            } else if (!d.successMessage.isEmpty()) {
                info(p, fmt(d.successMessage));
            }
        }
    }

    // ------------------------------------------------------------------ objetivos

    private static boolean objectiveMet(ServerPlayer p, MomentDef d, RevilData data) {
        return switch (d.objective.toLowerCase()) {
            case "bunker" -> data.bunkerContains(p);
            case "above" -> p.blockPosition().getY() >= d.objectiveY;
            case "below" -> p.blockPosition().getY() <= d.objectiveY;
            case "underwater" -> p.isUnderWater();
            case "base" -> nearBase(p, d);
            default -> true;
        };
    }

    private static boolean nearBase(ServerPlayer p, MomentDef d) {
        BlockPos rp = p.getRespawnPosition();
        String rd;
        if (rp == null) {
            rp = p.getServer().overworld().getSharedSpawnPos();
            rd = "minecraft:overworld";
        } else {
            rd = p.getRespawnDimension().location().toString();
        }
        if (!rd.equals(dimOf(p))) return false;
        double dx = p.getX() - rp.getX(), dz = p.getZ() - rp.getZ();
        return dx * dx + dz * dz <= (double) d.baseRadius * d.baseRadius;
    }

    private static String failReason(MomentDef d) {
        return switch (d.objective.toLowerCase()) {
            case "bunker" -> "no lleg\u00f3 al b\u00fanker";
            case "above" -> "no estuvo por encima de la capa " + d.objectiveY;
            case "below" -> "no descendi\u00f3 a la capa " + d.objectiveY;
            case "underwater" -> "no se sumergi\u00f3";
            case "base" -> "no estaba en su base";
            default -> "no cumpli\u00f3 el objetivo";
        };
    }

    /** objectiveMode=during: dano cada segundo a quien no cumple (solo una vez terminada la espera). */
    private static void damageViolators(MinecraftServer server, Run r) {
        MomentDef d = r.def;
        RevilData data = RevilData.get(server);
        for (ServerPlayer p : affected(server, d)) {
            if (objectiveMet(p, d, data)) continue;
            VIOLATORS.put(p.getUUID(), server.getTickCount() + 30);
            if (!RevilConfig.deadly) {
                if (r.age % 200 == 0) {
                    p.sendSystemMessage(Component.literal("\u00a7e[PRUEBA] \u00a7fRecibir\u00edas da\u00f1o: " + failReason(d) + "."));
                }
            } else {
                p.hurt(p.damageSources().magic(), d.gasDamage);
            }
        }
    }

    // ------------------------------------------------------------------ castigo

    private static void fail(MinecraftServer server, ServerPlayer p, MomentDef d, String why) {
        String name = p.getGameProfile().getName();
        if (!RevilConfig.deadly) {
            p.sendSystemMessage(Component.literal("\u00a7e[PRUEBA] \u00a7fHabr\u00edas fallado: " + why
                + ". (Con /revil config deadly true el castigo es real)"));
            return;
        }
        String action = d.failAction.toLowerCase();
        if (RevilConfig.totemSaves && !action.equals("none") && consumeTotem(p)) {
            info(p, "\u00a76Tu t\u00f3tem te salv\u00f3 del momento ReviiL.");
            return;
        }
        switch (action) {
            case "none" -> { }
            case "damage" -> p.hurt(p.damageSources().generic(), d.failDamage);
            case "lightning" -> {
                strike(p);
                p.kill();
            }
            case "absorb" -> {
                absorbFx(p, ParticleTypes.REVERSE_PORTAL);
                p.kill();
            }
            case "gas" -> {
                boolean exists = false;
                for (Gas g : GAS) if (g.uuid.equals(p.getUUID()) && g.def.id.equals(d.id)) exists = true;
                if (!exists) GAS.add(new Gas(p.getUUID(), d));
            }
            case "command" -> runCommand(server, d.failCommand.replace("%player%", name));
            default -> p.kill();
        }
        if (RevilConfig.broadcastFails) {
            server.getPlayerList().broadcastSystemMessage(Component.literal(
                "\u00a7c\u2620 \u00a7f" + name + " \u00a77" + why + "."), false);
        }
    }

    private static void absorbFx(ServerPlayer p, ParticleOptions fx) {
        ServerLevel lv = (ServerLevel) p.level();
        lv.sendParticles(fx, p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.4, 0.8, 0.4, 0.3);
        RevilSounds.at(lv, p.getX(), p.getY(), p.getZ(), "entity.enderman.teleport", SoundSource.HOSTILE, 1.0f, 0.5f);
    }

    /** Muerte por agujero negro / supernova (respeta modo pruebas y totem). */
    private static void deathBy(MinecraftServer server, ServerPlayer p, String why, ParticleOptions fx) {
        String name = p.getGameProfile().getName();
        if (!RevilConfig.deadly) {
            p.sendSystemMessage(Component.literal("\u00a7e[PRUEBA] \u00a7fHabr\u00edas muerto: " + why + "."));
            return;
        }
        if (RevilConfig.totemSaves && consumeTotem(p)) {
            info(p, "\u00a76Tu t\u00f3tem te salv\u00f3.");
            return;
        }
        absorbFx(p, fx);
        p.kill();
        if (RevilConfig.broadcastFails) {
            server.getPlayerList().broadcastSystemMessage(Component.literal(
                "\u00a7c\u2620 \u00a7f" + name + " \u00a77" + why + "."), false);
        }
    }

    /** Gas: el dano empieza en gasDamage y sube un 10% por segundo (hasta x3) hasta que cumplas o mueras. */
    private static void tickGas(MinecraftServer server) {
        if (GAS.isEmpty()) return;
        RevilData data = RevilData.get(server);
        Iterator<Gas> it = GAS.iterator();
        while (it.hasNext()) {
            Gas g = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(g.uuid);
            if (p == null) continue;
            if (!p.isAlive()) {
                it.remove();
                continue;
            }
            if (objectiveMet(p, g.def, data)) {
                info(p, "\u00a7aEl gas ya no te afecta.");
                it.remove();
            } else {
                g.seconds++;
                float dmg = g.def.gasDamage * Math.min(3.0f, 1.0f + 0.1f * g.seconds);
                p.hurt(p.damageSources().magic(), dmg);
            }
        }
        if (GAS.isEmpty()) syncAll(server);   // apaga el shader de gas
    }

    private static boolean consumeTotem(ServerPlayer p) {
        ItemStack main = p.getMainHandItem();
        if (main.is(Items.TOTEM_OF_UNDYING)) {
            main.shrink(1);
            return true;
        }
        ItemStack off = p.getOffhandItem();
        if (off.is(Items.TOTEM_OF_UNDYING)) {
            off.shrink(1);
            return true;
        }
        return false;
    }

    private static void strike(ServerPlayer p) {
        ServerLevel lv = (ServerLevel) p.level();
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(lv);
        if (bolt == null) return;
        bolt.moveTo(p.getX(), p.getY(), p.getZ());
        bolt.setVisualOnly(true);
        lv.addFreshEntity(bolt);
    }

    // ------------------------------------------------------------------ AGUJEROS NEGROS

    /** Coloca los agujeros negros en el cielo alrededor del bunker (o del spawn); iran bajando y acercandose. */
    private static void placeHoles(MinecraftServer server, Run r) {
        MomentDef d = r.def;
        RevilData data = RevilData.get(server);
        double cx, cy, cz;
        if (data.hasBunker) {
            cx = (data.x1 + data.x2) / 2.0;
            cy = data.y2;
            cz = (data.z1 + data.z2) / 2.0;
            r.holeDim = data.bunkerDim;
        } else {
            BlockPos sp = server.overworld().getSharedSpawnPos();
            cx = sp.getX();
            cy = sp.getY();
            cz = sp.getZ();
            r.holeDim = "minecraft:overworld";
        }
        ServerLevel lv = levelOf(server, r.holeDim);
        int n = d.blackHoles;
        for (int i = 0; i < n; i++) {
            double ang = (i / (double) n) * Math.PI * 2 + RNG.nextDouble() * 0.8;
            double far = 80 + RNG.nextDouble() * 60, near = 45 + RNG.nextDouble() * 30;
            Hole h = new Hole();
            h.sx = cx + Math.cos(ang) * far;
            h.sz = cz + Math.sin(ang) * far;
            h.sy = cy + 70 + RNG.nextDouble() * 40;
            h.ex = cx + Math.cos(ang) * near;
            h.ez = cz + Math.sin(ang) * near;
            double gy = cy;
            int ix = (int) Math.floor(h.ex), iz = (int) Math.floor(h.ez);
            if (lv != null && lv.hasChunkAt(new BlockPos(ix, 64, iz))) {
                gy = lv.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ix, iz);
            }
            h.ey = gy + 26;
            h.x = h.sx;
            h.y = h.sy;
            h.z = h.sz;
            h.baseRadius = d.blackHoleRadius;
            h.radius = d.blackHoleRadius * 0.6f;
            r.holes.add(h);
        }
    }

    /**
     * Cada tick: los agujeros bajan y crecen; el nivel (0-10) sube con el tiempo. Absorben bloques de la superficie
     * (mas cuanto mayor el nivel), jalan a los jugadores fuera del bunker y matan a quien los toca.
     */
    private static void tickHoles(MinecraftServer server, Run r) {
        MomentDef d = r.def;
        double prog = r.progress();
        r.level = 10.0 * prog;
        double ease = prog * prog * (3.0 - 2.0 * prog);
        for (Hole h : r.holes) {
            h.x = h.sx + (h.ex - h.sx) * ease;
            h.y = h.sy + (h.ey - h.sy) * ease;
            h.z = h.sz + (h.ez - h.sz) * ease;
            h.radius = h.baseRadius * (0.6f + (d.blackHoleGrowth - 0.6f) * (float) prog);
        }
        ServerLevel lv = levelOf(server, r.holeDim);
        if (lv == null || r.level < 0.3) return;
        RevilData data = RevilData.get(server);
        double pullR = 14.0 + r.level * 6.0;

        if (d.blackHoleAbsorb && r.age % 4 == 0) absorbBlocks(lv, r, data, pullR);
        if (r.age % 2 == 0) pullPlayers(server, r, data, pullR);
    }

    private static boolean nearBunkerXZ(RevilData data, String dim, double x, double z, int margin) {
        return data.hasBunker && data.bunkerDim.equals(dim)
            && x >= data.x1 - margin && x <= data.x2 + 1 + margin
            && z >= data.z1 - margin && z <= data.z2 + 1 + margin;
    }

    private static void absorbBlocks(ServerLevel lv, Run r, RevilData data, double pullR) {
        int perHole = Math.max(1, (int) Math.round((1.0 + r.level * 1.2) / Math.max(1, r.holes.size())));
        for (int hi = 0; hi < r.holes.size(); hi++) {
            Hole h = r.holes.get(hi);
            for (int i = 0; i < perHole; i++) {
                if (ABSORBING.size() >= 160) return;
                double ang = RNG.nextDouble() * Math.PI * 2;
                double rr = Math.sqrt(RNG.nextDouble()) * pullR;
                int x = (int) Math.floor(h.x + Math.cos(ang) * rr);
                int z = (int) Math.floor(h.z + Math.sin(ang) * rr);
                if (!lv.hasChunkAt(new BlockPos(x, 64, z))) continue;
                int y = lv.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
                double dx = x + 0.5 - h.x, dy = y - h.y, dz = z + 0.5 - h.z;
                if (dx * dx + dy * dy + dz * dz > pullR * pullR) continue;
                if (nearBunkerXZ(data, r.holeDim, x, z, 4)) continue;           // el bunker no se toca
                BlockPos pos = new BlockPos(x, y, z);
                BlockState st = lv.getBlockState(pos);
                if (st.isAir() || !st.getFluidState().isEmpty() || st.getDestroySpeed(lv, pos) < 0
                    || lv.getBlockEntity(pos) != null) continue;
                FallingBlockEntity fb = FallingBlockEntity.fall(lv, pos, st);
                fb.disableDrop();
                fb.setNoGravity(true);
                ABSORBING.add(new Absorb(fb.getUUID(), r, hi));
            }
        }
    }

    private static void pullPlayers(MinecraftServer server, Run r, RevilData data, double pullR) {
        for (ServerPlayer p : affected(server, r.def)) {
            if (!dimOf(p).equals(r.holeDim) || data.bunkerContains(p)) continue;   // dentro del bunker: a salvo
            for (Hole h : r.holes) {
                Vec3 to = new Vec3(h.x - p.getX(), h.y - (p.getY() + 0.9), h.z - p.getZ());
                double dist = to.length();
                if (dist < h.radius * 0.5 + 1.5) {                                  // tocado por el agujero negro
                    if (!RevilConfig.deadly && r.age % 100 != 0) break;
                    deathBy(server, p, "fue absorbido por un agujero negro", ParticleTypes.REVERSE_PORTAL);
                    break;
                }
                if (dist < pullR) {
                    double fall = 1.0 - dist / pullR;
                    Vec3 add = to.normalize().scale((0.04 + 0.02 * r.level) * fall + 0.01);
                    p.setDeltaMovement(p.getDeltaMovement().add(add));
                    p.hurtMarked = true;
                    p.fallDistance = 0f;
                }
            }
        }
    }

    /** Mueve los bloques succionados hacia su agujero negro y los elimina al llegar. */
    private static void tickAbsorbing(MinecraftServer server) {
        if (ABSORBING.isEmpty()) return;
        Iterator<Absorb> it = ABSORBING.iterator();
        while (it.hasNext()) {
            Absorb a = it.next();
            Entity e = findEntity(server, a.id);
            if (e == null || !e.isAlive()) {
                it.remove();
                continue;
            }
            if (!RUNS.contains(a.run) || a.hole >= a.run.holes.size()) {   // el momento termino: los bloques desaparecen
                e.discard();
                it.remove();
                continue;
            }
            Hole h = a.run.holes.get(a.hole);
            Vec3 to = new Vec3(h.x - e.getX(), h.y - e.getY(), h.z - e.getZ());
            double dist = to.length();
            if (dist < h.radius * 0.5 + 2.0) {
                if (e.level() instanceof ServerLevel lv) {
                    lv.sendParticles(ParticleTypes.PORTAL, e.getX(), e.getY(), e.getZ(), 6, 0.3, 0.3, 0.3, 0.4);
                }
                e.discard();
                it.remove();
                continue;
            }
            double speed = Math.min(2.0, 0.3 + 0.12 * a.run.level + 10.0 / (dist + 10.0));
            e.setNoGravity(true);
            e.setDeltaMovement(to.normalize().scale(speed));
            e.hurtMarked = true;
        }
    }

    // ------------------------------------------------------------------ SUPERNOVA

    /** Epicentro: el definido con /revil supernova set, o el centro del bunker, o el spawn. */
    private static void placeNova(MinecraftServer server, Run r) {
        RevilData data = RevilData.get(server);
        if (data.hasNova) {
            r.novaPos = new double[]{data.nx, data.ny, data.nz};
            r.novaDim = data.novaDim;
        } else if (data.hasBunker) {
            r.novaPos = new double[]{(data.x1 + data.x2) / 2.0, data.y2, (data.z1 + data.z2) / 2.0};
            r.novaDim = data.bunkerDim;
        } else {
            BlockPos sp = server.overworld().getSharedSpawnPos();
            r.novaPos = new double[]{sp.getX(), sp.getY(), sp.getZ()};
            r.novaDim = "minecraft:overworld";
        }
    }

    private static void supernovaAmbient(MinecraftServer server, Run r) {
        double prog = r.progress();
        for (ServerPlayer p : affected(server, r.def)) {
            RevilSounds.toPlayer(p, "block.beacon.ambient", (float) (0.3 + prog), 0.5f);
            if (prog > 0.6) RevilSounds.toPlayer(p, "entity.warden.heartbeat", (float) (0.3 + prog * 0.7), 0.5f);
        }
    }

    /** Onda expansiva: avanza desde el epicentro; mata a quien alcanza (salvo el bunker si es seguro). */
    private static void tickNovas(MinecraftServer server) {
        if (NOVAS.isEmpty()) return;
        RevilData data = RevilData.get(server);
        boolean removed = false;
        Iterator<Nova> it = NOVAS.iterator();
        while (it.hasNext()) {
            Nova n = it.next();
            n.age++;
            ServerLevel lv = levelOf(server, n.dim);
            if (lv == null) {
                it.remove();
                removed = true;
                continue;
            }
            double radius = n.radius();
            if (n.age == 1) novaBoom(server, lv, n);

            for (ServerPlayer p : affected(server, n.def)) {
                if (!dimOf(p).equals(n.dim) || n.hit.contains(p.getUUID())) continue;
                double dx = p.getX() - n.x, dy = p.getY() - n.y, dz = p.getZ() - n.z;
                double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (dist > n.def.supernovaMaxRadius || dist > radius) continue;
                n.hit.add(p.getUUID());
                if (n.def.supernovaSafe.equalsIgnoreCase("bunker") && data.bunkerContains(p)) continue;   // a salvo
                deathBy(server, p, "la onda expansiva de la supernova lo alcanz\u00f3", ParticleTypes.EXPLOSION_EMITTER);
            }

            if (!n.columns.isEmpty() && n.craterIdx < n.columns.size()) tickCrater(lv, n, data);

            boolean craterDone = n.columns.isEmpty() || n.craterIdx >= n.columns.size();
            if (craterDone && n.age > 100 && radius > n.def.supernovaMaxRadius + 20) {
                it.remove();
                removed = true;
            }
        }
        if (removed) syncAll(server);
    }

    private static void novaBoom(MinecraftServer server, ServerLevel lv, Nova n) {
        lv.explode(null, n.x, n.y + 1.0, n.z, 10.0f, Level.ExplosionInteraction.NONE);
        lv.sendParticles(ParticleTypes.EXPLOSION_EMITTER, n.x, n.y + 2.0, n.z, 14, 6.0, 3.0, 6.0, 0.0);
        if (!n.def.sounds) return;
        for (ServerPlayer p : affected(server, n.def)) {
            if (!dimOf(p).equals(n.dim)) continue;
            RevilSounds.toPlayer(p, "entity.lightning_bolt.thunder", 1.0f, 0.5f);
            RevilSounds.toPlayer(p, "entity.generic.explode", 1.0f, 0.5f);
        }
    }

    /** Crater esferico opcional (supernovaCrater > 0): se excava por columnas, de dentro hacia fuera. */
    private static void tickCrater(ServerLevel lv, Nova n, RevilData data) {
        int radius = (int) n.def.supernovaCrater;
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int budget = 80;
        while (budget-- > 0 && n.craterIdx < n.columns.size()) {
            int[] c = n.columns.get(n.craterIdx++);
            int x = (int) Math.floor(n.x) + c[0], z = (int) Math.floor(n.z) + c[1];
            if (!lv.hasChunkAt(new BlockPos(x, 64, z))) continue;
            if (nearBunkerXZ(data, n.dim, x, z, 3)) continue;
            double h = Math.sqrt(Math.max(0, radius * radius - (double) (c[0] * c[0] + c[1] * c[1])));
            int cy = (int) Math.floor(n.y);
            int yMin = Math.max(lv.getMinBuildHeight() + 1, (int) (cy - h * 0.7));
            int yMax = Math.min(lv.getMaxBuildHeight() - 1, (int) (cy + h));
            for (int y = yMax; y >= yMin; y--) {
                pos.set(x, y, z);
                BlockState s = lv.getBlockState(pos);
                if (s.isAir() || s.getDestroySpeed(lv, pos) < 0) continue;
                lv.setBlock(pos, air, 2);
            }
        }
    }

    // ------------------------------------------------------------------ efectos varios

    private static void swap(List<ServerPlayer> aff) {
        int n = aff.size();
        if (n < 2) return;
        List<ServerPlayer> order = new ArrayList<>(aff);
        Collections.shuffle(order, new java.util.Random(RNG.nextLong()));
        ServerLevel[] lv = new ServerLevel[n];
        double[] x = new double[n], y = new double[n], z = new double[n];
        float[] yr = new float[n], xr = new float[n];
        for (int i = 0; i < n; i++) {
            ServerPlayer p = order.get(i);
            lv[i] = (ServerLevel) p.level();
            x[i] = p.getX();
            y[i] = p.getY();
            z[i] = p.getZ();
            yr[i] = p.getYRot();
            xr[i] = p.getXRot();
        }
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;                      // desplazamiento ciclico: nadie se queda en su sitio
            order.get(i).teleportTo(lv[j], x[j], y[j], z[j], yr[j], xr[j]);
        }
    }

    /** Creeper en la posicion de cada jugador (via /summon para respetar los NBT de vanilla). */
    private static void spawnCreepers(MinecraftServer server, MomentDef d) {
        for (ServerPlayer p : affected(server, d)) {
            boolean powered = d.creeperMode.equalsIgnoreCase("electric")
                || (d.creeperMode.equalsIgnoreCase("any") && RNG.nextBoolean());
            String cmd = String.format(Locale.ROOT,
                "execute in %s run summon minecraft:creeper %.2f %.2f %.2f {powered:%db,Health:%.1ff}",
                dimOf(p), p.getX(), p.getY(), p.getZ(), powered ? 1 : 0, d.creeperHealth);
            runCommand(server, cmd);
        }
    }

    private static void strikeNearPlayer(MinecraftServer server, MomentDef d) {
        List<ServerPlayer> aff = affected(server, d);
        if (aff.isEmpty()) return;
        ServerPlayer p = aff.get(RNG.nextInt(aff.size()));
        ServerLevel lv = (ServerLevel) p.level();
        double ang = RNG.nextDouble() * Math.PI * 2;
        double dist = 8 + RNG.nextDouble() * 16;
        int x = (int) Math.floor(p.getX() + Math.cos(ang) * dist);
        int z = (int) Math.floor(p.getZ() + Math.sin(ang) * dist);
        if (!lv.hasChunkAt(new BlockPos(x, 64, z))) return;
        int y = lv.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(lv);
        if (bolt == null) return;
        bolt.moveTo(x + 0.5, y, z + 0.5);
        lv.addFreshEntity(bolt);
    }

    /** Maldicion de la Luna: el primero que la mire muere y el momento termina. */
    private static boolean checkMoon(MinecraftServer server, Run r) {
        MomentDef d = r.def;
        for (ServerPlayer p : affected(server, d)) {
            ServerLevel lv = (ServerLevel) p.level();
            if (lv.dimension() != Level.OVERWORLD || lv.isDay() || !lv.canSeeSky(p.blockPosition())) continue;
            float theta = lv.getTimeOfDay(1.0f) * ((float) Math.PI * 2f);
            Vec3 moon = new Vec3(Math.sin(theta), -Math.cos(theta), 0.0);   // opuesta al sol
            if (moon.y < 0.05) continue;
            if (p.getViewVector(1.0f).dot(moon) > 0.985) {
                String name = p.getGameProfile().getName();
                if (RevilConfig.deadly) {
                    if (!(RevilConfig.totemSaves && consumeTotem(p))) p.kill();
                    if (RevilConfig.broadcastFails) {
                        server.getPlayerList().broadcastSystemMessage(Component.literal(
                            "\u00a7c\u2620 \u00a7f" + name + " \u00a77mir\u00f3 a la Luna. La maldici\u00f3n se ha disipado."), false);
                    }
                } else {
                    server.getPlayerList().broadcastSystemMessage(Component.literal(
                        "\u00a7e[PRUEBA] \u00a7f" + name + " mir\u00f3 a la Luna: habr\u00eda muerto. Maldici\u00f3n disipada."), false);
                }
                endRun(server, r, false, true);
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ bunker (particulas azules)

    private static void bunkerParticles(MinecraftServer server) {
        RevilData data = RevilData.get(server);
        if (!data.hasBunker) return;
        ParticleOptions blue = new DustParticleOptions(new Vector3f(0.25f, 0.45f, 1.0f), 1.6f);
        double x1 = data.x1, y1 = data.y1, z1 = data.z1;
        double x2 = data.x2 + 1.0, y2 = data.y2 + 1.0, z2 = data.z2 + 1.0;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!dimOf(p).equals(data.bunkerDim)) continue;
            if (p.getX() < x1 - 128 || p.getX() > x2 + 128 || p.getZ() < z1 - 128 || p.getZ() > z2 + 128) continue;
            ServerLevel lv = (ServerLevel) p.level();
            edge(lv, p, blue, x1, y1, z1, x2, y1, z1);
            edge(lv, p, blue, x1, y2, z1, x2, y2, z1);
            edge(lv, p, blue, x1, y1, z2, x2, y1, z2);
            edge(lv, p, blue, x1, y2, z2, x2, y2, z2);
            edge(lv, p, blue, x1, y1, z1, x1, y1, z2);
            edge(lv, p, blue, x2, y1, z1, x2, y1, z2);
            edge(lv, p, blue, x1, y2, z1, x1, y2, z2);
            edge(lv, p, blue, x2, y2, z1, x2, y2, z2);
            edge(lv, p, blue, x1, y1, z1, x1, y2, z1);
            edge(lv, p, blue, x2, y1, z1, x2, y2, z1);
            edge(lv, p, blue, x1, y1, z2, x1, y2, z2);
            edge(lv, p, blue, x2, y1, z2, x2, y2, z2);
        }
    }

    private static void edge(ServerLevel lv, ServerPlayer p, ParticleOptions o,
                             double ax, double ay, double az, double bx, double by, double bz) {
        double len = Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay) + (bz - az) * (bz - az));
        int n = Math.max(1, Math.min(40, (int) Math.ceil(len / 2.0)));
        for (int i = 0; i <= n; i++) {
            double t = i / (double) n;
            lv.sendParticles(p, o, true, ax + (bx - ax) * t, ay + (by - ay) * t, az + (bz - az) * t, 1, 0, 0, 0, 0);
        }
    }

    // ------------------------------------------------------------------ herobrine

    public static UUID spawnHerobrine(ServerPlayer near, float damage) {
        ServerLevel lv = (ServerLevel) near.level();
        for (int tries = 0; tries < 8; tries++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double dist = 28 + RNG.nextDouble() * 18;
            int x = (int) Math.floor(near.getX() + Math.cos(ang) * dist);
            int z = (int) Math.floor(near.getZ() + Math.sin(ang) * dist);
            if (!lv.hasChunkAt(new BlockPos(x, 64, z))) continue;
            int y = lv.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            HerobrineEntity h = ModEntities.HEROBRINE.get().create(lv);
            if (h == null) return null;
            h.moveTo(x + 0.5, y, z + 0.5, RNG.nextFloat() * 360f, 0f);
            if (h.getAttribute(Attributes.ATTACK_DAMAGE) != null) {
                h.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(damage);
            }
            h.setPersistenceRequired();
            lv.addFreshEntity(h);
            return h.getUUID();
        }
        return null;
    }

    public static int clearHerobrines(MinecraftServer server) {
        List<Entity> found = new ArrayList<>();
        for (ServerLevel lv : server.getAllLevels()) {
            for (Entity e : lv.getAllEntities()) if (e instanceof HerobrineEntity) found.add(e);
        }
        for (Entity e : found) e.discard();
        LANTERN_HITS.clear();
        return found.size();
    }

    /** Item de ahuyentar en mano. La linterna del mod solo vale si esta ENCENDIDA. */
    private static boolean holdsBanishItem(ServerPlayer p, MomentDef d) {
        for (ItemStack s : List.of(p.getMainHandItem(), p.getOffhandItem())) {
            ResourceLocation key = ForgeRegistries.ITEMS.getKey(s.getItem());
            if (key == null || !d.banishItems.contains(key.toString())) continue;
            if (s.getItem() instanceof FlashlightItem && !FlashlightItem.isOn(s)) continue;
            return true;
        }
        return false;
    }

    /** Apuntar a Herobrine con la linterna encendida lo paraliza y a 1 segundo lo hace desaparecer. */
    private static void tickLantern(MinecraftServer server) {
        Set<UUID> pointed = new HashSet<>();
        for (Run r : RUNS) {
            if (!r.activated || !r.def.herobrine || r.herobrines.isEmpty()) continue;
            for (ServerPlayer p : affected(server, r.def)) {
                if (!holdsBanishItem(p, r.def)) continue;
                Vec3 look = p.getViewVector(1.0f).normalize();
                for (UUID id : r.herobrines) {
                    Entity h = findEntity(server, id);
                    if (h == null) continue;
                    Vec3 to = new Vec3(h.getX() - p.getX(), h.getEyeY() - p.getEyeY(), h.getZ() - p.getZ());
                    double dist = to.length();
                    if (dist > 24 || dist < 0.5) continue;
                    if (look.dot(to.normalize()) > 0.975 && p.hasLineOfSight(h)) {
                        pointed.add(id);
                        if (h instanceof HerobrineEntity he) he.beam();   // la luz lo paraliza
                    }
                }
            }
        }
        LANTERN_HITS.keySet().removeIf(id -> !pointed.contains(id));
        for (UUID id : pointed) {
            int n = LANTERN_HITS.merge(id, 1, Integer::sum);
            if (n >= 10) {
                Entity h = findEntity(server, id);
                if (h != null) {
                    ServerLevel lv = (ServerLevel) h.level();
                    lv.sendParticles(ParticleTypes.POOF, h.getX(), h.getY() + 1.0, h.getZ(), 20, 0.3, 0.6, 0.3, 0.05);
                    RevilSounds.at(lv, h.getX(), h.getY(), h.getZ(), "entity.enderman.teleport", SoundSource.HOSTILE, 1.0f, 0.5f);
                    h.discard();
                }
                LANTERN_HITS.remove(id);
                for (Run r : RUNS) r.herobrines.remove(id);
            }
        }
    }

    // ------------------------------------------------------------------ bloqueos de gamerules / hora

    private static void lockRegen(MinecraftServer server) {
        GameRules.BooleanValue rule = server.getGameRules().getRule(GameRules.RULE_NATURAL_REGENERATION);
        if (regenLocks == 0) {
            savedRegen = rule.get();
            rule.set(false, server);
        }
        regenLocks++;
    }

    private static void unlockRegen(MinecraftServer server) {
        if (regenLocks == 0) return;
        regenLocks--;
        if (regenLocks == 0) {
            server.getGameRules().getRule(GameRules.RULE_NATURAL_REGENERATION).set(savedRegen, server);
        }
    }

    private static void lockTime(MinecraftServer server, long time) {
        ServerLevel ow = server.overworld();
        GameRules.BooleanValue rule = server.getGameRules().getRule(GameRules.RULE_DAYLIGHT);
        if (timeLocks == 0) {
            savedTime = ow.getDayTime();
            savedDaylight = rule.get();
            lockStartTick = server.getTickCount();
            rule.set(false, server);
        }
        timeLocks++;
        ow.setDayTime(time);
    }

    private static void unlockTime(MinecraftServer server) {
        if (timeLocks == 0) return;
        timeLocks--;
        if (timeLocks == 0) {
            ServerLevel ow = server.overworld();
            long elapsed = savedDaylight ? (server.getTickCount() - lockStartTick) : 0L;
            ow.setDayTime(savedTime + elapsed);                       // el dia sigue como si no hubiera pasado nada raro
            server.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(savedDaylight, server);
        }
    }
}
