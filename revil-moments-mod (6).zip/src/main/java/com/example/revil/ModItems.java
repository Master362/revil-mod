package com.example.revil;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, RevilMod.MODID);

    public static final RegistryObject<Item> FLASHLIGHT =
        ITEMS.register("flashlight", () -> new FlashlightItem(new Item.Properties().stacksTo(1)));
}
