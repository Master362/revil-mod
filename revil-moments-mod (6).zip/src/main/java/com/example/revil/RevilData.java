package com.example.revil;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

/** Datos guardados en el mundo: la zona del bunker. */
public class RevilData extends SavedData {
    public boolean hasBunker = false;
    public String bunkerDim = "";
    public int x1, y1, z1, x2, y2, z2;

    /** Epicentro de las supernovas (si no se define: el centro del bunker, o el spawn). */
    public boolean hasNova = false;
    public String novaDim = "";
    public double nx, ny, nz;

    public static RevilData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(RevilData::load, RevilData::new, "revil_data");
    }

    public void setBunker(String dim, int ax, int ay, int az, int bx, int by, int bz) {
        hasBunker = true;
        bunkerDim = dim;
        x1 = Math.min(ax, bx);
        y1 = Math.min(ay, by);
        z1 = Math.min(az, bz);
        x2 = Math.max(ax, bx);
        y2 = Math.max(ay, by);
        z2 = Math.max(az, bz);
        setDirty();
    }

    public void setNova(String dim, double x, double y, double z) {
        hasNova = true;
        novaDim = dim;
        nx = x;
        ny = y;
        nz = z;
        setDirty();
    }

    public void clearNova() {
        hasNova = false;
        setDirty();
    }

    public String describeNova() {
        return hasNova ? "(" + (int) nx + ", " + (int) ny + ", " + (int) nz + ") en " + novaDim : "sin definir (se usa el bunker o el spawn)";
    }

    public void clearBunker() {
        hasBunker = false;
        setDirty();
    }

    public boolean bunkerContains(ServerPlayer p) {
        if (!hasBunker) return false;
        if (!p.level().dimension().location().toString().equals(bunkerDim)) return false;
        double x = p.getX(), y = p.getY(), z = p.getZ();
        return x >= x1 && x <= x2 + 1 && y >= y1 && y <= y2 + 1 && z >= z1 && z <= z2 + 1;
    }

    public String center() {
        return hasBunker ? "X: " + (x1 + x2) / 2 + " // Z: " + (z1 + z2) / 2 : "(bunker sin configurar)";
    }

    public String describeBunker() {
        return hasBunker
            ? "(" + x1 + ", " + y1 + ", " + z1 + ") a (" + x2 + ", " + y2 + ", " + z2 + ") en " + bunkerDim
            : "sin configurar";
    }

    public static RevilData load(CompoundTag t) {
        RevilData d = new RevilData();
        d.hasBunker = t.getBoolean("hasBunker");
        d.bunkerDim = t.getString("bunkerDim");
        d.x1 = t.getInt("x1");
        d.y1 = t.getInt("y1");
        d.z1 = t.getInt("z1");
        d.x2 = t.getInt("x2");
        d.y2 = t.getInt("y2");
        d.z2 = t.getInt("z2");
        d.hasNova = t.getBoolean("hasNova");
        d.novaDim = t.getString("novaDim");
        d.nx = t.getDouble("nx");
        d.ny = t.getDouble("ny");
        d.nz = t.getDouble("nz");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putBoolean("hasBunker", hasBunker);
        t.putString("bunkerDim", bunkerDim);
        t.putInt("x1", x1);
        t.putInt("y1", y1);
        t.putInt("z1", z1);
        t.putInt("x2", x2);
        t.putInt("y2", y2);
        t.putInt("z2", z2);
        t.putBoolean("hasNova", hasNova);
        t.putString("novaDim", novaDim);
        t.putDouble("nx", nx);
        t.putDouble("ny", ny);
        t.putDouble("nz", nz);
        return t;
    }
}
