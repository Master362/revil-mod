package com.example.revil;

import java.util.ArrayList;
import java.util.List;

/**
 * Definicion de un momento ReviiL (config/revilmoments/moments.json).
 * Edita los existentes o crea los tuyos copiando uno y cambiando el "id". Los textos aceptan codigos & (&c rojo, &l negrita).
 * Placeholders en textos: %bunker% (coordenadas del bunker) y %y% (objectiveY).
 * Los momentos son ACUMULATIVOS: puedes activar varios a la vez.
 */
public class MomentDef {
    public String id = "";

    // ---- textos ----
    public String title = "&c&lMomento ReviiL";
    /** Subtitulo (nombre del momento). */
    public String name = "";
    /** Linea de chat con la descripcion. */
    public String description = "";
    public List<String> messages = new ArrayList<>();
    /** Texto del HUD sobre la cuenta atras (vacio = automatico segun el objetivo). */
    public String objectiveText = "";
    public String successMessage = "";

    // ---- tiempo ----
    /** 0 = sin limite (termina por si solo cuando se cumple su condicion, p. ej. la maldicion de la luna). */
    public int durationSeconds = 120;
    public boolean showTimer = false;
    public boolean sounds = true;
    /**
     * Segundos desde que empieza el momento hasta que EMPIEZAN los efectos (blindness, swap, creepers, herobrine,
     * dano continuo "during"...). El momento termina en durationSeconds contando desde el inicio (incluye este retraso).
     */
    public int delaySeconds = 0;

    // ---- objetivo: none | bunker | above | below | underwater | base ----
    public String objective = "none";
    /** Y para above (>=) y below (<=). Capa negativa = -1. */
    public int objectiveY = 250;
    /** Radio alrededor de la cama/respawn para objective=base. */
    public int baseRadius = 80;
    /** end = se evalua al terminar el tiempo | during = dano cada segundo mientras no se cumpla. */
    public String objectiveMode = "end";

    // ---- castigo: none | kill | lightning | gas | damage | command ----
    public String failAction = "kill";
    public float failDamage = 10f;
    /** Dano por segundo del gas (failAction=gas o objectiveMode=during). 1 = medio corazon. */
    public float gasDamage = 1f;
    public String failCommand = "";

    // ---- efectos ----
    public int blindnessSeconds = 0;
    public boolean noRegen = false;
    public boolean hideHealth = false;
    public boolean swapPositions = false;
    /** none | electric | any */
    public String creeperMode = "none";
    public float creeperHealth = 1f;
    /** Cuantas veces (en momentos aleatorios) aparece un creeper en la posicion de cada jugador. */
    public int creeperEvents = 0;
    /** Fuerza la hora del dia (0-24000) durante el momento (-1 = no). Eclipse/luna de sangre = 18000. */
    public int forceTime = -1;
    public boolean thunderstorm = false;
    public int lightningIntervalSeconds = 4;
    public boolean disableNether = false;
    public boolean herobrine = false;
    public int herobrineCount = 1;
    /** Dano de cada golpe de Herobrine (20 = 10 corazones). */
    public float herobrineDamage = 14f;
    /** Items que hacen desaparecer a Herobrine al apuntarle 1 segundo (la linterna debe estar ENCENDIDA). */
    public List<String> banishItems = new ArrayList<>(List.of("revilmoments:flashlight"));
    /** El primer jugador que mire a la Luna muere y el momento termina. */
    public boolean moonCurse = false;
    /** Contorno de particulas azules en la zona del bunker mientras dura el momento. */
    public boolean bunkerParticles = false;
    /** Cantidad de agujeros negros visibles en el cielo (shader). Se colocan alrededor del bunker (o del spawn). */
    public int blackHoles = 0;
    /** Tamano visual inicial de cada agujero negro, en bloques. */
    public float blackHoleRadius = 22f;
    /** Factor de crecimiento hasta el nivel 10 (radio final = radio inicial x este factor). */
    public float blackHoleGrowth = 2.2f;
    /**
     * Los agujeros negros bajan y se acercan; su "nivel" sube de 0 a 10 durante el momento. Absorben bloques de la superficie
     * (cada vez mas), jalan a los jugadores que NO estan en el bunker (y los matan al tocarlos) y al llegar al nivel 10
     * (fin del tiempo) absorben a todos los que sigan fuera del bunker (usa failAction "absorb").
     */
    public boolean blackHoleAbsorb = true;
    /** Shader de eclipse: mundo oscuro y frio + disco negro con corona en el sol. */
    public boolean eclipseShader = false;

    // ---- supernova: la estrella crece durante el momento y EXPLOTA al terminar el tiempo (shader + onda expansiva) ----
    public boolean supernova = false;
    /** Altura de la estrella sobre el epicentro (bloques). */
    public float supernovaHeight = 90f;
    /** Alcance maximo de la onda expansiva (bloques). Quien este mas lejos sobrevive. */
    public float supernovaMaxRadius = 300f;
    /** Velocidad de la onda expansiva (bloques por segundo). */
    public float supernovaSpeed = 70f;
    /** Quien se salva dentro del alcance: bunker (estar dentro del bunker) | none. */
    public String supernovaSafe = "bunker";
    /** Radio del crater que deja la explosion (0 = no daña el terreno). Respeta el bunker. */
    public float supernovaCrater = 0f;
    /** Dimensiones afectadas (vacio = las de config.json). */
    public List<String> dimensions = new ArrayList<>();

    // ---- al terminar ----
    public String endCommand = "";
    /** Id del siguiente momento (para encadenar). */
    public String then = "";
    public int thenDelaySeconds = 5;

    public MomentDef() {
    }

    public MomentDef(String id) {
        this.id = id;
    }
}
