package com.example.revil;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.registries.ForgeRegistries;

/** Sonidos de vanilla buscados por id. Pitch minimo real de Minecraft: 0.5. */
public class RevilSounds {
    private static final Map<String, SoundEvent> CACHE = new HashMap<>();

    private static SoundEvent get(String path) {
        return CACHE.computeIfAbsent(path,
            k -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("minecraft", k)));
    }

    public static void toPlayer(ServerPlayer p, String id, float vol, float pitch) {
        SoundEvent s = get(id);
        if (s != null) p.playNotifySound(s, SoundSource.AMBIENT, vol, pitch);
    }

    public static void at(ServerLevel level, double x, double y, double z, String id,
                          SoundSource src, float vol, float pitch) {
        SoundEvent s = get(id);
        if (s != null) level.playSound(null, x, y, z, s, src, vol, pitch);
    }
}
