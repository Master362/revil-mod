package com.example.revil.client;

import com.example.revil.HerobrineEntity;
import com.example.revil.RevilMod;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class HerobrineRenderer extends HumanoidMobRenderer<HerobrineEntity, HumanoidModel<HerobrineEntity>> {
    private static final ResourceLocation TEXTURE =
        new ResourceLocation(RevilMod.MODID, "textures/entity/herobrine.png");

    public HerobrineRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
        this.addLayer(new Eyes(this));
    }

    @Override
    public ResourceLocation getTextureLocation(HerobrineEntity entity) {
        return TEXTURE;
    }

    /** Ojos blancos que brillan en la oscuridad (se ven aunque sea de noche o haya eclipse). */
    private static class Eyes extends EyesLayer<HerobrineEntity, HumanoidModel<HerobrineEntity>> {
        private static final RenderType EYES = RenderType.eyes(
            new ResourceLocation(RevilMod.MODID, "textures/entity/herobrine_eyes.png"));

        Eyes(RenderLayerParent<HerobrineEntity, HumanoidModel<HerobrineEntity>> parent) {
            super(parent);
        }

        @Override
        public RenderType renderType() {
            return EYES;
        }
    }
}
