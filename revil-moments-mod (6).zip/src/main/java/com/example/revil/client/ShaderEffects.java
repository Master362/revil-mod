package com.example.revil.client;

import com.example.revil.FlashlightItem;
import com.example.revil.HerobrineEntity;
import com.example.revil.RevilMod;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.slf4j.Logger;

/**
 * Efectos de pantalla (post-procesado con PostChain de vanilla; assets/revilmoments/shaders).
 * Si un shader falla se desactiva solo, sin cerrar el juego. /revilfx off|on|reset los controla en TU cliente.
 *
 *   gas / eclipse   se aplican al mundo y, en un SEGUNDO PASE al empezar el HUD, tambien a la MANO y los objetos en mano
 *                   (se dibujan despues del mundo; sin esto se verian "encendidos" en un entorno oscuro)
 *   blackhole       lente gravitacional + horizonte + disco de acrecion (los agujeros bajan, crecen y absorben)
 *   supernova       estrella que crece, destello, onda expansiva con aberracion cromatica y tinte calido
 *   herobrine_eyes  brillo y luz de los ojos de Herobrine sobre las superficies cercanas
 *   flashlight      haz de la linterna
 */
@Mod.EventBusSubscriber(modid = RevilMod.MODID, value = Dist.CLIENT)
public class ShaderEffects {
    private static final Logger LOG = LogUtils.getLogger();
    private static final Map<String, PostChain> CHAINS = new HashMap<>();
    private static final Map<PostChain, List<PostPass>> PASSES = new HashMap<>();
    private static final Set<String> FAILED = new HashSet<>();
    private static int lastW = -1, lastH = -1;

    public static boolean enabled = true;

    public static void reset() {
        for (PostChain c : CHAINS.values()) {
            try {
                c.close();
            } catch (Exception ignored) {
                // nada
            }
        }
        CHAINS.clear();
        PASSES.clear();
        FAILED.clear();
        lastW = -1;
        lastH = -1;
    }

    private static PostChain chain(Minecraft mc, String name) {
        if (FAILED.contains(name)) return null;
        PostChain c = CHAINS.get(name);
        if (c == null) {
            try {
                c = new PostChain(mc.getTextureManager(), mc.getResourceManager(), mc.getMainRenderTarget(),
                    new ResourceLocation(RevilMod.MODID, "shaders/post/" + name + ".json"));
                c.resize(mc.getWindow().getWidth(), mc.getWindow().getHeight());
                CHAINS.put(name, c);
            } catch (Exception ex) {
                LOG.error("Revil Moments: no se pudo cargar el shader '{}', se desactiva.", name, ex);
                FAILED.add(name);
                return null;
            }
        }
        return c;
    }

    /**
     * PostChain no expone sus pases en 1.20.1: se localiza la lista (la unica de PostPass) por reflexion,
     * sin depender de nombres internos, asi funciona igual en desarrollo y en el juego final.
     */
    @SuppressWarnings("unchecked")
    private static List<PostPass> passesOf(PostChain chain) {
        List<PostPass> cached = PASSES.get(chain);
        if (cached != null) return cached;
        for (Field f : PostChain.class.getDeclaredFields()) {
            if (!List.class.isAssignableFrom(f.getType())) continue;
            try {
                f.setAccessible(true);
                Object v = f.get(chain);
                if (v instanceof List<?> l && !l.isEmpty() && l.get(0) instanceof PostPass) {
                    PASSES.put(chain, (List<PostPass>) l);
                    return (List<PostPass>) l;
                }
            } catch (Exception ignored) {
                // se prueba el siguiente campo
            }
        }
        throw new IllegalStateException("No se encontraron los pases del PostChain");
    }

    /** Fija uniforms float (pares nombre, valor) en todos los pases de la cadena. */
    private static void set(PostChain c, Object... kv) {
        List<PostPass> passes = passesOf(c);
        for (int i = 0; i + 1 < kv.length; i += 2) {
            String name = (String) kv[i];
            float val = ((Number) kv[i + 1]).floatValue();
            for (PostPass pass : passes) pass.getEffect().safeGetUniform(name).set(val);
        }
    }

    /** @return {u, v, w(distancia en profundidad)} o null si esta detras de la camara */
    private static float[] project(Matrix4f view, Matrix4f proj, Vec3 cam, double wx, double wy, double wz) {
        Vector4f v = new Vector4f((float) (wx - cam.x), (float) (wy - cam.y), (float) (wz - cam.z), 1.0f);
        view.transform(v);
        proj.transform(v);
        if (v.w <= 0.05f) return null;
        return new float[]{(v.x / v.w) * 0.5f + 0.5f, (v.y / v.w) * 0.5f + 0.5f, v.w};
    }

    private static boolean flashlightOn(Minecraft mc) {
        if (mc.player == null || !mc.options.getCameraType().isFirstPerson()) return false;
        return FlashlightItem.isOn(mc.player.getMainHandItem()) || FlashlightItem.isOn(mc.player.getOffhandItem());
    }

    private static List<HerobrineEntity> herobrines(Minecraft mc) {
        List<HerobrineEntity> list = new ArrayList<>();
        for (Entity en : mc.level.entitiesForRendering()) {
            if (en instanceof HerobrineEntity h && h.isAlive() && h.distanceToSqr(mc.player) < 90.0 * 90.0) list.add(h);
        }
        list.sort(Comparator.comparingDouble(h -> h.distanceToSqr(mc.player)));
        return list;
    }

    // ------------------------------------------------------------------ pase del MUNDO

    @SubscribeEvent
    public static void onRenderStage(RenderLevelStageEvent e) {
        if (!enabled || e.getStage() != RenderLevelStageEvent.Stage.AFTER_WEATHER) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        float gas = ClientRevil.gasBlend, ecl = ClientRevil.eclipseBlend, bh = ClientRevil.holeBlend;
        boolean light = flashlightOn(mc);
        boolean holes = bh > 0.01f && !ClientRevil.holes.isEmpty();
        boolean nova = ClientRevil.nova != null;
        List<HerobrineEntity> eyes = herobrines(mc);
        if (gas < 0.01f && ecl < 0.01f && !holes && !light && !nova && eyes.isEmpty()) return;

        float pt = e.getPartialTick();
        int w = mc.getWindow().getWidth(), h = mc.getWindow().getHeight();
        if (w != lastW || h != lastH) {
            for (PostChain c : CHAINS.values()) c.resize(w, h);
            lastW = w;
            lastH = h;
        }
        float aspect = (float) w / (float) Math.max(1, h);
        float phase = (ClientRevil.ticks + pt) / 20.0f;
        float near = 0.05f;
        float far = mc.gameRenderer.getDepthFar();
        Matrix4f view = e.getPoseStack().last().pose();
        Matrix4f proj = e.getProjectionMatrix();
        Vec3 cam = e.getCamera().getPosition();

        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.resetTextureMatrix();
        try {
            if (gas >= 0.01f) {
                PostChain c = chain(mc, "gas");
                if (c != null) {
                    set(c, "Strength", gas, "Aspect", aspect, "Phase", phase, "HandOnly", 0f);
                    c.process(pt);
                }
            }
            if (ecl >= 0.01f) renderEclipse(mc, view, proj, cam, ecl, aspect, phase, pt);
            if (holes) renderHoles(mc, view, proj, cam, bh, aspect, phase, near, far, pt);
            if (nova) renderNova(mc, view, proj, cam, aspect, phase, near, far, pt);
            if (!eyes.isEmpty()) renderEyes(mc, eyes, view, proj, cam, aspect, phase, near, far, pt);
            if (light) {
                PostChain c = chain(mc, "flashlight");
                if (c != null) {
                    float flick = 1.0f + 0.01f * Mth.sin(phase * 53.0f);
                    set(c, "Intensity", flick, "Aspect", aspect, "CenterX", 0.5f, "CenterY", 0.5f,
                        "Inner", 0.07f, "Outer", 0.36f, "Range", 32.0f, "Near", near, "Far", far, "Phase", phase);
                    c.process(pt);
                }
            }
        } catch (Exception ex) {
            LOG.error("Revil Moments: error en los shaders, se desactivan.", ex);
            enabled = false;
        }
        mc.getMainRenderTarget().bindWrite(false);
        RenderSystem.enableDepthTest();
    }

    // ------------------------------------------------------------------ pase de la MANO (despues del mundo)

    /**
     * La mano y los objetos en mano se dibujan DESPUES del mundo (con el buffer de profundidad limpio), asi que el pase
     * del mundo no los toca. Aqui, al empezar el HUD, se repite el oscurecimiento (eclipse) y el tinte (gas) solo sobre
     * los pixeles con profundidad < 1, que son unicamente los de la mano.
     */
    @SubscribeEvent
    public static void onGuiPre(RenderGuiEvent.Pre e) {
        if (!enabled) return;
        float gas = ClientRevil.gasBlend, ecl = ClientRevil.eclipseBlend;
        if (gas < 0.01f && ecl < 0.01f) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        float pt = e.getPartialTick();
        float aspect = (float) mc.getWindow().getWidth() / (float) Math.max(1, mc.getWindow().getHeight());
        float phase = (ClientRevil.ticks + pt) / 20.0f;

        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.resetTextureMatrix();
        try {
            if (gas >= 0.01f) {
                PostChain c = chain(mc, "gas");
                if (c != null) {
                    set(c, "Strength", gas, "Aspect", aspect, "Phase", phase, "HandOnly", 1f);
                    c.process(pt);
                }
            }
            if (ecl >= 0.01f) {
                PostChain c = chain(mc, "eclipse");
                if (c != null) {
                    set(c, "Strength", ecl, "Aspect", aspect, "CenterX", 0.5f, "CenterY", 0.5f,
                        "Radius", 0.05f, "Visible", 0f, "Phase", phase, "HandOnly", 1f);
                    c.process(pt);
                }
            }
        } catch (Exception ex) {
            LOG.error("Revil Moments: error en el pase de la mano, se desactivan los shaders.", ex);
            enabled = false;
        }
        mc.getMainRenderTarget().bindWrite(true);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
    }

    // ------------------------------------------------------------------ efectos individuales

    private static void renderEclipse(Minecraft mc, Matrix4f view, Matrix4f proj, Vec3 cam,
                                      float strength, float aspect, float phase, float pt) {
        PostChain c = chain(mc, "eclipse");
        if (c == null) return;
        // posicion del sol segun la hora del dia
        float theta = mc.level.getTimeOfDay(pt) * ((float) Math.PI * 2f);
        double sx = cam.x - Math.sin(theta) * 100.0, sy = cam.y + Math.cos(theta) * 100.0, sz = cam.z;
        float[] sp = project(view, proj, cam, sx, sy, sz);
        float visible = 0f, cx = 0.5f, cy = 0.5f, radius = 0.05f;
        if (sp != null && sp[0] > -0.3f && sp[0] < 1.3f && sp[1] > -0.3f && sp[1] < 1.3f && sy > cam.y) {
            visible = 1f;
            cx = sp[0];
            cy = sp[1];
            radius = Mth.clamp(7.0f * proj.m11() / (2.0f * sp[2]), 0.01f, 0.4f);
        }
        set(c, "Strength", strength, "Aspect", aspect, "CenterX", cx, "CenterY", cy,
            "Radius", radius, "Visible", visible, "Phase", phase, "HandOnly", 0f);
        c.process(pt);
    }

    private static void renderHoles(Minecraft mc, Matrix4f view, Matrix4f proj, Vec3 cam, float blend,
                                    float aspect, float phase, float near, float far, float pt) {
        PostChain c = chain(mc, "blackhole");
        if (c == null) return;
        List<double[]> list = ClientRevil.holes;
        int count = 0;
        for (double[] hole : list) {
            if (count >= 3) break;
            float[] p = project(view, proj, cam, hole[0], hole[1], hole[2]);
            if (p == null) continue;
            float radius = Mth.clamp((float) hole[3] * proj.m11() / (2.0f * p[2]), 0.01f, 0.9f);
            if (p[0] + radius < -0.2f || p[0] - radius > 1.2f || p[1] + radius < -0.2f || p[1] - radius > 1.2f) continue;
            set(c, "CenterX", p[0], "CenterY", p[1], "Radius", radius, "Strength", blend, "Aspect", aspect,
                "Phase", phase + count * 1.7f, "HoleDist", p[2], "Near", near, "Far", far);
            c.process(pt);
            count++;
        }
    }

    /** Supernova: estrella sobre el epicentro (crece con la carga) y, al explotar, destello + anillo de onda + tinte. */
    private static void renderNova(Minecraft mc, Matrix4f view, Matrix4f proj, Vec3 cam, float aspect, float phase,
                                   float near, float far, float pt) {
        PostChain c = chain(mc, "supernova");
        double[] n = ClientRevil.nova;
        if (c == null || n == null) return;

        float charge = Mth.clamp(ClientRevil.novaCharge, 0f, 1f);
        boolean exploded = n[5] > 0.5;
        float since = (ClientRevil.novaSince + pt) / 20.0f;           // segundos desde la explosion
        double ex = n[0], ey = n[1], ez = n[2];

        // estrella
        float[] sp = project(view, proj, cam, ex, ey + n[3], ez);
        float cxs = -5f, cys = 0.5f, starR = 0.004f, starDist = 1.0e6f;
        if (sp != null) {
            float worldR = (3.0f + 22.0f * (exploded ? 1.0f : charge)) * (exploded ? 1.0f + since * 2.0f : 1.0f);
            starR = Mth.clamp(worldR * proj.m11() / (2.0f * sp[2]), 0.004f, 0.9f);
            cxs = sp[0];
            cys = sp[1];
            starDist = sp[2];
        }

        Vec3 epi = new Vec3(ex, ey, ez);
        double distEpi = cam.distanceTo(epi);
        Vec3 look = mc.player.getViewVector(pt);
        float lookDot = (float) Math.max(0.0, look.dot(epi.subtract(cam).normalize()));

        float epiX = 0.5f, epiY = 0.5f, waveR = -1f, waveW = 0.03f, flash, tint = 0f;
        if (exploded) {
            double waveBlocks = Math.min(since * n[7], n[8] + 50.0);
            float[] ep = project(view, proj, cam, ex, ey + 2.0, ez);
            if (ep != null) {
                epiX = ep[0];
                epiY = ep[1];
                if (waveBlocks < distEpi) {
                    waveR = Mth.clamp((float) waveBlocks * proj.m11() / (2.0f * ep[2]), 0.0f, 3.0f);
                    waveW = Mth.clamp(waveR * 0.12f, 0.02f, 0.2f);
                }
            }
            flash = (float) Math.exp(-since * 0.7) * (0.35f + 0.65f * lookDot);
            if (waveBlocks >= distEpi) {                              // la onda ya paso por la camara
                double passed = (waveBlocks - distEpi) / Math.max(1.0, n[7]);
                flash = Math.max(flash, (float) Math.exp(-passed * 1.2));
            }
            tint = (float) Math.exp(-since * 0.12) * 0.4f;
        } else {
            flash = charge * charge * 0.12f * lookDot;
        }

        set(c, "CenterX", cxs, "CenterY", cys, "StarR", starR, "StarDist", starDist, "EpiX", epiX, "EpiY", epiY,
            "WaveR", waveR, "WaveW", waveW, "Charge", exploded ? 1.0f : charge, "Flash", flash, "Tint", tint,
            "Aspect", aspect, "Phase", phase, "Near", near, "Far", far, "Exploded", exploded ? 1.0f : 0.0f);
        c.process(pt);
    }

    /** Ojos de Herobrine: dos puntos de luz (con halo y luz sobre superficies cercanas), hasta 3 Herobrines. */
    private static void renderEyes(Minecraft mc, List<HerobrineEntity> list, Matrix4f view, Matrix4f proj, Vec3 cam,
                                   float aspect, float phase, float near, float far, float pt) {
        PostChain c = chain(mc, "herobrine_eyes");
        if (c == null) return;
        int count = 0;
        for (HerobrineEntity h : list) {
            if (count >= 3) break;
            Vec3 pos = h.getPosition(pt);
            Vec3 fwd = h.getViewVector(pt);
            Vec3 fh = new Vec3(fwd.x, 0.0, fwd.z);
            fh = fh.lengthSqr() < 1.0e-4 ? new Vec3(0.0, 0.0, 1.0) : fh.normalize();
            Vec3 lat = new Vec3(-fh.z, 0.0, fh.x);
            double ey = pos.y + h.getEyeHeight();
            Vec3 center = new Vec3(pos.x + fh.x * 0.27, ey, pos.z + fh.z * 0.27);
            Vec3 e1 = center.add(lat.scale(0.125));
            Vec3 e2 = center.subtract(lat.scale(0.125));
            float[] p1 = project(view, proj, cam, e1.x, e1.y, e1.z);
            float[] p2 = project(view, proj, cam, e2.x, e2.y, e2.z);
            if (p1 == null || p2 == null) continue;

            double dist = cam.distanceTo(center);
            float fade = (float) Mth.clamp((85.0 - dist) / 25.0, 0.0, 1.0);
            float facing = (float) Mth.clamp(fwd.dot(cam.subtract(center).normalize()), 0.0, 1.0);
            float intensity = fade * (0.3f + 0.7f * facing);
            float size = Mth.clamp(0.22f * proj.m11() / (2.0f * p1[2]), 0.003f, 0.08f);

            set(c, "E1X", p1[0], "E1Y", p1[1], "E2X", p2[0], "E2Y", p2[1], "EyeDist", p1[2], "Size", size,
                "Intensity", intensity, "Aspect", aspect, "Phase", phase + count * 2.3f,
                "Near", near, "Far", far, "Range", 6.0f);
            c.process(pt);
            count++;
        }
    }
}
