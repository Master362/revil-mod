package com.example.revil.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** HUD: una linea por cada momento activo (objetivo en negrita con contorno + cuenta atras en caja oscura). */
public class RevilOverlay {

    public static void render(ForgeGui gui, GuiGraphics g, float pt, int sw, int sh) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || ClientRevil.lines.isEmpty()) return;

        float y = 6f;
        for (ClientRevil.Line l : ClientRevil.lines) {
            y = drawLine(g, mc, l, pt, sw, y) + 5f;
        }
    }

    private static String format(int secs) {
        int h = secs / 3600, m = (secs % 3600) / 60, s = secs % 60;
        return h > 0 ? String.format("%d:%02d:%02d", h, m, s) : String.format("%02d:%02d", m, s);
    }

    /** @return la Y donde termina la linea dibujada */
    private static float drawLine(GuiGraphics g, Minecraft mc, ClientRevil.Line l, float pt, int sw, float topY) {
        Font font = mc.font;
        PoseStack pose = g.pose();

        if (!l.text.isEmpty()) {
            float ts = 1.2f;
            Component main = Component.literal(l.text).withStyle(Style.EMPTY.withBold(true));
            String plain = ChatFormatting.stripFormatting(l.text);
            Component outline = Component.literal(plain == null ? "" : plain).withStyle(Style.EMPTY.withBold(true));
            int x = -font.width(main) / 2;

            pose.pushPose();
            pose.translate(sw / 2f, topY, 0f);
            pose.scale(ts, ts, 1f);
            for (int ox = -1; ox <= 1; ox++) {
                for (int oy = -1; oy <= 1; oy++) {
                    if (ox != 0 || oy != 0) g.drawString(font, outline, x + ox, oy, 0xFF000000, false);
                }
            }
            g.drawString(font, main, x, 0, 0xFFFFFFFF, false);
            pose.popPose();
            topY += 9f * ts + 3f;
        }

        if (l.timer && l.total > 0) {
            float rem = Math.max(0f, l.remaining - pt);
            String t = format((int) Math.ceil(rem / 20.0));
            float scale = 1.4f;

            pose.pushPose();
            pose.translate(sw / 2f, topY + 7f * scale, 0f);
            pose.scale(scale, scale, 1f);
            int tw = font.width(t);
            g.fill(-tw / 2 - 5, -7, tw / 2 + 5, 8, 0xB0000000);
            g.renderOutline(-tw / 2 - 5, -7, tw + 10, 15, 0x99D0D0D0);
            g.drawString(font, t, -tw / 2, -4, 0xFFFFFFFF, true);
            pose.popPose();
            topY += 15f * scale;
        }
        return topY;
    }
}
