package com.example.revil.client;

import com.example.revil.RevilMod;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /revilfx on|off|reset : controla los shaders solo en TU cliente (por si usas un shaderpack o te dan problemas). */
@Mod.EventBusSubscriber(modid = RevilMod.MODID, value = Dist.CLIENT)
public class ClientCommands {
    @SubscribeEvent
    public static void onRegister(RegisterClientCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("revilfx")
            .then(Commands.literal("on").executes(c -> {
                ShaderEffects.enabled = true;
                ShaderEffects.reset();
                c.getSource().sendSuccess(() -> Component.literal("Shaders de Revil Moments: activados."), false);
                return 1;
            }))
            .then(Commands.literal("off").executes(c -> {
                ShaderEffects.enabled = false;
                c.getSource().sendSuccess(() -> Component.literal("Shaders de Revil Moments: desactivados."), false);
                return 1;
            }))
            .then(Commands.literal("reset").executes(c -> {
                ShaderEffects.reset();
                c.getSource().sendSuccess(() -> Component.literal("Shaders recargados."), false);
                return 1;
            })));
    }
}
