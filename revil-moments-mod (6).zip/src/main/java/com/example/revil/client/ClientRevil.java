package com.example.revil.client;

import com.example.revil.StatePacket;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.Mth;

/** Estado en el cliente: lineas de HUD, vida oculta y parametros de los shaders (suavizados). */
public class ClientRevil {
    public static class Line {
        public final String text;
        public int remaining;
        public final int total;
        public final boolean timer;

        Line(String text, int remaining, int total, boolean timer) {
            this.text = text;
            this.remaining = remaining;
            this.total = total;
            this.timer = timer;
        }
    }

    public static boolean hideHealth = false;
    public static List<Line> lines = new ArrayList<>();

    // objetivos que manda el servidor
    public static float eclipse = 0f, gas = 0f;
    public static List<double[]> holes = new ArrayList<>();
    /** x, y, z, altura, carga, explotada, ticksDesdeExplosion, velocidad, radioMax (o null). */
    public static double[] nova = null;
    public static float novaCharge = 0f;
    public static float novaSince = 0f;   // ticks desde la explosion (avanza solo entre paquetes)
    // valores suavizados que usan los shaders
    public static float eclipseBlend = 0f, gasBlend = 0f, holeBlend = 0f;
    public static int ticks = 0;

    public static void apply(StatePacket p) {
        hideHealth = p.hideHealth;
        List<Line> l = new ArrayList<>();
        for (StatePacket.Entry e : p.entries) l.add(new Line(e.text, e.remaining, e.total, e.timer));
        lines = l;
        eclipse = p.eclipse;
        gas = p.gas;
        holes = new ArrayList<>(p.holes);
        nova = p.nova;
        if (nova != null) novaSince = (float) nova[6];
    }

    private static float approach(float cur, float target, float step) {
        return cur + Mth.clamp(target - cur, -step, step);
    }

    public static void tick(boolean paused) {
        ticks++;
        eclipseBlend = approach(eclipseBlend, eclipse, 0.02f);
        gasBlend = approach(gasBlend, gas, 0.03f);
        holeBlend = approach(holeBlend, holes.isEmpty() ? 0f : 1f, 0.012f);
        if (nova != null) {
            novaCharge = approach(novaCharge, (float) nova[4], 0.01f);
            if (nova[5] > 0.5) novaSince += 1f;
        } else {
            novaCharge = 0f;
            novaSince = 0f;
        }
        if (paused) return;
        for (Line l : lines) if (l.timer && l.remaining > 0) l.remaining--;
    }

    public static void clear() {
        hideHealth = false;
        lines = new ArrayList<>();
        eclipse = gas = 0f;
        holes = new ArrayList<>();
        nova = null;
        novaCharge = 0f;
        novaSince = 0f;
        eclipseBlend = gasBlend = holeBlend = 0f;
    }
}
